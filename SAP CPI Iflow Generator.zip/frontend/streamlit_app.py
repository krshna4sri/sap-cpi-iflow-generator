import streamlit as st

st.title("SAP CPI iFlow Generator")

files = st.file_uploader("Upload iFlows", accept_multiple_files=True)

if st.button("Load Templates"):
    st.success("Templates Loaded")

prompt = st.text_input("Enter Prompt")

if st.button("Generate"):
    st.success("iFlow Generated")
