SAP CPI iFlow Generator

Run Backend:
pip install -r backend/requirements.txt
uvicorn backend.app.main:app --reload

Run Frontend:
streamlit run frontend/streamlit_app.py
