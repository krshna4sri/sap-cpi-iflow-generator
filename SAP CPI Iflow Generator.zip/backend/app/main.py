from fastapi import FastAPI
from .api.routes import router

app = FastAPI(title="SAP CPI iFlow Generator")
app.include_router(router, prefix="/api")
