from fastapi import APIRouter, UploadFile, File
from typing import List

router = APIRouter()

@router.post("/templates/load")
async def load_templates(files: List[UploadFile] = File(...)):
    return {"message": f"Loaded {len(files)} templates"}

@router.post("/generate")
async def generate(prompt: str):
    return {"message": f"Generated iFlow for: {prompt}"}

@router.post("/deploy")
async def deploy():
    return {"message": "Deploy triggered"}
