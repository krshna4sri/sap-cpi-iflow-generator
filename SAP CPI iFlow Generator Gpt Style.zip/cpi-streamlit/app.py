"""
SAP CPI iFlow Intelligence Generator
═══════════════════════════════════════════════════════════════
Chat-first Streamlit UI — like ChatGPT but for SAP CPI iFlows.

Everything in one app.py:
  • Sidebar  : Upload folder | Train | Settings | Status
  • Main     : Pure chat interface — type what you want, get an iFlow
  • Engine   : Ollama (local LLM) → fallback to Python rule-based
  • Groovy   : Pre-written pattern library, filled from your templates
  • Training : Extracts XML patterns + Groovy scripts from 200+ iFlows
               Builds searchable JSON index used at generation time
"""

import io
import json
import os
import re
import time
import zipfile
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import requests
import streamlit as st

# ─── Paths ────────────────────────────────────────────────────────────────────
TEMPLATE_DIR = Path("template_library")
INDEX_FILE   = Path("trained_index/iflow_index.json")
OUTPUT_DIR   = Path("output_zips")

for d in [TEMPLATE_DIR, INDEX_FILE.parent, OUTPUT_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# ─── Ollama config ────────────────────────────────────────────────────────────
OLLAMA_HOST  = os.getenv("OLLAMA_HOST",  "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2")

TEXT_SUFFIXES = {
    ".iflw", ".groovy", ".prop", ".propdef", ".mf",
    ".edmx", ".xsd", ".wsdl", ".mmap", ".project", ".xml"
}

# ═══════════════════════════════════════════════════════════════════════════════
# BUILT-IN SKELETON iFlow XMLs
# ═══════════════════════════════════════════════════════════════════════════════

def _make_skeleton(method: str, odata_op: str) -> str:
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<bpmn2:definitions xmlns:bpmn2="http://www.omg.org/spec/BPMN/20100524/MODEL"
  xmlns:ifl="http:///com.sap.ifl.model/Ifl.xsd" id="Def1"
  targetNamespace="http://sap.com/xi/SAP_XI_TradeSpecificNamespace">
  <bpmn2:collaboration id="Col1">
    <bpmn2:participant id="Sender"  name="Sender_HTTPS"  processRef="SP"/>
    <bpmn2:participant id="Recv"    name="Receiver_OData" processRef="RP"/>
    <bpmn2:participant id="IP"      name="%%IFLOW_NAME%%"  processRef="IPR"/>
    <bpmn2:messageFlow id="MFin"  sourceRef="Sender" targetRef="SE1"/>
    <bpmn2:messageFlow id="MFout" sourceRef="EE1"   targetRef="Recv"/>
  </bpmn2:collaboration>
  <bpmn2:process id="SP"  name="Sender_HTTPS"  isExecutable="false"/>
  <bpmn2:process id="RP"  name="Receiver_OData" isExecutable="false"/>
  <bpmn2:process id="IPR" name="%%IFLOW_NAME%%" isExecutable="true">
    <bpmn2:extensionElements>
      <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>IFlow</ifl:value></ifl:property>
    </bpmn2:extensionElements>
    <bpmn2:startEvent id="SE1" name="Start">
      <bpmn2:extensionElements>
        <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>StartEvent</ifl:value></ifl:property>
        <ifl:property><ifl:key>address</ifl:key><ifl:value>%%SENDER_PATH%%</ifl:value></ifl:property>
        <ifl:property><ifl:key>httpMethod</ifl:key><ifl:value>{method}</ifl:value></ifl:property>
        <ifl:property><ifl:key>enableBasicAuthentication</ifl:key><ifl:value>true</ifl:value></ifl:property>
      </bpmn2:extensionElements>
      <bpmn2:outgoing>S1</bpmn2:outgoing>
    </bpmn2:startEvent>
    <bpmn2:serviceTask id="CM1" name="Set_Headers">
      <bpmn2:extensionElements>
        <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>ContentModifier</ifl:value></ifl:property>
        <ifl:property><ifl:key>messageHeaderTable</ifl:key><ifl:value>Accept:application/json</ifl:value></ifl:property>
      </bpmn2:extensionElements>
      <bpmn2:incoming>S1</bpmn2:incoming><bpmn2:outgoing>S2</bpmn2:outgoing>
    </bpmn2:serviceTask>
    <bpmn2:scriptTask id="GS1" name="Transform" scriptFormat="groovy">
      <bpmn2:extensionElements>
        <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>ScriptTask</ifl:value></ifl:property>
        <ifl:property><ifl:key>scriptFile</ifl:key><ifl:value>script/%%IFLOW_NAME%%_transform.groovy</ifl:value></ifl:property>
      </bpmn2:extensionElements>
      <bpmn2:incoming>S2</bpmn2:incoming><bpmn2:outgoing>S3</bpmn2:outgoing>
    </bpmn2:scriptTask>
    <bpmn2:serviceTask id="OD1" name="{odata_op}_%%ENTITY_NAME%%">
      <bpmn2:extensionElements>
        <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>OData</ifl:value></ifl:property>
        <ifl:property><ifl:key>address</ifl:key><ifl:value>%%ODATA_ADDRESS%%</ifl:value></ifl:property>
        <ifl:property><ifl:key>entitySetName</ifl:key><ifl:value>%%ENTITY_NAME%%</ifl:value></ifl:property>
        <ifl:property><ifl:key>operation</ifl:key><ifl:value>{odata_op}</ifl:value></ifl:property>
        <ifl:property><ifl:key>authenticationMethod</ifl:key><ifl:value>BasicAuthentication</ifl:value></ifl:property>
        <ifl:property><ifl:key>credentialName</ifl:key><ifl:value>S4HANA_CRED</ifl:value></ifl:property>
      </bpmn2:extensionElements>
      <bpmn2:incoming>S3</bpmn2:incoming><bpmn2:outgoing>S4</bpmn2:outgoing>
    </bpmn2:serviceTask>
    <bpmn2:endEvent id="EE1" name="End">
      <bpmn2:extensionElements>
        <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>EndEvent</ifl:value></ifl:property>
      </bpmn2:extensionElements>
      <bpmn2:incoming>S4</bpmn2:incoming>
    </bpmn2:endEvent>
    <bpmn2:sequenceFlow id="S1" sourceRef="SE1" targetRef="CM1"/>
    <bpmn2:sequenceFlow id="S2" sourceRef="CM1" targetRef="GS1"/>
    <bpmn2:sequenceFlow id="S3" sourceRef="GS1" targetRef="OD1"/>
    <bpmn2:sequenceFlow id="S4" sourceRef="OD1" targetRef="EE1"/>
  </bpmn2:process>
</bpmn2:definitions>'''

SKELETONS = {
    "GET":    _make_skeleton("GET",    "GET"),
    "CREATE": _make_skeleton("POST",   "CREATE"),
    "UPDATE": _make_skeleton("PUT",    "UPDATE"),
    "DELETE": _make_skeleton("DELETE", "DELETE"),
}

MANIFEST_TPL = (
    "Manifest-Version: 1.0\n"
    "Bundle-ManifestVersion: 2\n"
    "Bundle-Name: {name}\n"
    "Bundle-SymbolicName: {aid}\n"
    "Bundle-Version: 1.0.0\n"
    "SAP-BundleType: IFlow\n"
)

# ═══════════════════════════════════════════════════════════════════════════════
# GROOVY PATTERN LIBRARY
# ═══════════════════════════════════════════════════════════════════════════════

GROOVY_PATTERNS = {
"GET": '''\
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

// GET Response Handler — Entity: {ENTITY} | Path: {PATH}
def Message processData(Message message) {
    try {
        def body = message.getBody(String.class)
        def log  = messageLogFactory.getMessageLog(message)
        if (log) log.addAttachmentAsString("GET_Response", body, "application/json")

        def json    = new JsonSlurper().parseText(body)
        def records = json?.d?.results ?: (json?.value ?: [])

        def output = records.collect { r -> [
            // TODO: map {ENTITY} fields here
            id          : r?.ObjectID    ?: r?.ID           ?: "",
            description : r?.Description ?: r?.Name         ?: "",
            status      : r?.Status      ?: "UNKNOWN",
            createdAt   : r?.CreatedAt   ?: "",
        ]}
        message.setBody(JsonOutput.toJson([results: output, count: output.size()]))
        message.setHeader("Content-Type",   "application/json")
        message.setHeader("X-Record-Count", output.size().toString())
    } catch (Exception e) {
        message.setBody(JsonOutput.toJson([error: "GET failed", detail: e.getMessage()]))
        throw new Exception("GET handler error: " + e.getMessage(), e)
    }
    return message
}''',

"CREATE": '''\
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.text.SimpleDateFormat

// CREATE Payload Builder — Entity: {ENTITY} | Path: {PATH}
def Message processData(Message message) {
    try {
        def body  = message.getBody(String.class)
        def log   = messageLogFactory.getMessageLog(message)
        if (log) log.addAttachmentAsString("CREATE_Input", body, "application/json")

        def input = new JsonSlurper().parseText(body)
        if (!input) throw new Exception("Empty input payload")

        def now = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(new Date())
        def payload = [
            // TODO: map {ENTITY} fields here
            ExternalID  : input?.id          ?: "",
            Description : input?.description ?: "",
            Status      : input?.status      ?: "ACTIVE",
            CreatedBy   : "CPI_INTEGRATION",
            CreatedAt   : now,
        ]
        if (!payload.ExternalID) throw new Exception("Required field 'id' is missing")
        message.setBody(JsonOutput.toJson(payload))
        message.setHeader("Content-Type", "application/json")
        message.setProperty("createdKey", payload.ExternalID)
    } catch (Exception e) {
        message.setBody(JsonOutput.toJson([error: "CREATE failed", detail: e.getMessage()]))
        throw new Exception("CREATE handler error: " + e.getMessage(), e)
    }
    return message
}''',

"UPDATE": '''\
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.text.SimpleDateFormat

// UPDATE Payload Builder — Entity: {ENTITY} | Path: {PATH}
def Message processData(Message message) {
    try {
        def body    = message.getBody(String.class)
        def headers = message.getHeaders()
        def input   = new JsonSlurper().parseText(body)
        if (!input) throw new Exception("Empty input payload")

        def key = input?.id ?: input?.ObjectID ?: headers?.get("entityKey") ?: ""
        if (!key) throw new Exception("Entity key not found in UPDATE request")

        def now = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(new Date())
        def payload = [:]
        if (input?.description != null) payload.Description    = input.description
        if (input?.status      != null) payload.Status         = input.status
        payload.LastModifiedAt = now
        payload.LastModifiedBy = "CPI_INTEGRATION"

        message.setProperty("entityKey", key)
        message.setBody(JsonOutput.toJson(payload))
        message.setHeader("Content-Type",  "application/json")
        message.setHeader("X-HTTP-Method", "PATCH")
    } catch (Exception e) {
        message.setBody(JsonOutput.toJson([error: "UPDATE failed", detail: e.getMessage()]))
        throw new Exception("UPDATE handler error: " + e.getMessage(), e)
    }
    return message
}''',

"DELETE": '''\
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

// DELETE Key Extractor — Entity: {ENTITY} | Path: {PATH}
def Message processData(Message message) {
    try {
        def body    = message.getBody(String.class)
        def headers = message.getHeaders()
        def key     = ""
        if (body?.trim()?.startsWith("{")) {
            def input = new JsonSlurper().parseText(body)
            key = input?.id ?: input?.ObjectID ?: input?.key ?: ""
        }
        if (!key) key = headers?.get("X-Entity-Key") ?: ""
        if (!key) throw new Exception("Entity key not found — provide 'id' in body or X-Entity-Key header")

        def log = messageLogFactory.getMessageLog(message)
        if (log) log.addAttachmentAsString("DELETE_Key", "Deleting {ENTITY}: " + key, "text/plain")

        message.setProperty("entityKey",  key)
        message.setProperty("entityName", "{ENTITY}")
        message.setHeader("X-Entity-Key",  key)
        message.setHeader("X-HTTP-Method", "DELETE")
        message.setBody("")
    } catch (Exception e) {
        message.setBody(JsonOutput.toJson([error: "DELETE failed", detail: e.getMessage()]))
        throw new Exception("DELETE handler error: " + e.getMessage(), e)
    }
    return message
}''',

"PASSTHROUGH": '''\
import com.sap.gateway.ip.core.customdev.util.Message

// Passthrough with Audit Logging
def Message processData(Message message) {
    try {
        def body = message.getBody(String.class)
        def log  = messageLogFactory.getMessageLog(message)
        if (log) {
            log.addAttachmentAsString("Payload", body, "text/plain")
            log.setStringProperty("Payload-Size", body?.length()?.toString() ?: "0")
        }
        message.setHeader("X-Source",    "SAP-CPI-PASSTHROUGH")
        message.setHeader("X-Processed", new Date().toString())
    } catch (Exception e) {
        throw new Exception("Passthrough error: " + e.getMessage(), e)
    }
    return message
}''',
}


# ═══════════════════════════════════════════════════════════════════════════════
# CORE PYTHON ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

def safe_slug(text: str) -> str:
    v = re.sub(r"[^A-Za-z0-9]+", "_", str(text).strip())
    return re.sub(r"_+", "_", v).strip("_") or "iflow"


def detect_operation(xml: str, filename: str = "") -> str:
    x = xml.upper()
    if any(t in x for t in ["<IFL:VALUE>POST</IFL:VALUE>", "HTTPMETHOD>POST<"]):    return "CREATE"
    if any(t in x for t in ["<IFL:VALUE>PUT</IFL:VALUE>", "<IFL:VALUE>PATCH</IFL:VALUE>"]): return "UPDATE"
    if "<IFL:VALUE>DELETE</IFL:VALUE>" in x: return "DELETE"
    if "<IFL:VALUE>GET</IFL:VALUE>"    in x: return "GET"
    if "<IFL:VALUE>CREATE</IFL:VALUE>" in x: return "CREATE"
    if "<IFL:VALUE>UPDATE</IFL:VALUE>" in x: return "UPDATE"
    fn = filename.upper()
    if any(w in fn for w in ["CREATE","POST","INSERT"]):     return "CREATE"
    if any(w in fn for w in ["UPDATE","PUT","PATCH","EDIT"]): return "UPDATE"
    if any(w in fn for w in ["DELETE","REMOVE"]):             return "DELETE"
    return "GET"


def extract_xml_props(xml: str) -> Dict:
    p = {
        "sender_path": "", "entity_name": "", "odata_address": "",
        "sender_adapter": "HTTPS", "receiver_adapter": "OData",
        "credential_name": "", "iflow_display_name": "",
    }
    for m in re.finditer(
            r"<ifl:key>address</ifl:key>\s*<ifl:value>([^<]+)</ifl:value>", xml):
        v = m.group(1).strip()
        if v.startswith("http"): p["odata_address"] = v
        elif v.startswith("/"):  p["sender_path"]   = v

    m = re.search(r"<ifl:key>entitySetName</ifl:key>\s*<ifl:value>([^<]+)</ifl:value>", xml)
    if m: p["entity_name"] = m.group(1).strip()

    m = re.search(r"<ifl:key>credentialName</ifl:key>\s*<ifl:value>([^<]+)</ifl:value>", xml)
    if m: p["credential_name"] = m.group(1).strip()

    m = re.search(r'<bpmn2:process[^>]+name="([^"]+)"[^>]+isExecutable="true"', xml)
    if m: p["iflow_display_name"] = m.group(1).strip()

    if   "SFTP"         in xml: p["sender_adapter"] = "SFTP"
    elif "ProcessDirect" in xml: p["sender_adapter"] = "ProcessDirect"
    elif "IDoc"         in xml: p["sender_adapter"] = "IDoc"
    elif "AS2"          in xml: p["sender_adapter"] = "AS2"

    if   "SOAP" in xml.upper(): p["receiver_adapter"] = "SOAP"
    elif "RFC"  in xml:         p["receiver_adapter"] = "RFC"
    return p


def parse_single_zip(zip_bytes: bytes, filename: str) -> Dict:
    rec = {
        "filename": filename, "id": safe_slug(Path(filename).stem),
        "name": Path(filename).stem, "operation": "GET",
        "xml": "", "groovy_scripts": [], "has_mapping": False,
        "iflow_files": [], "groovy_files": [], "file_size": len(zip_bytes),
        "props": {},
    }
    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
            names = zf.namelist()
            rec["has_mapping"] = any(n.endswith(".mmap") for n in names)
            rec["iflow_files"] = [n for n in names if n.endswith(".iflw")]
            rec["groovy_files"]= [n for n in names if n.endswith(".groovy")]
            for n in names:
                if n.endswith(".iflw"):
                    xml = zf.read(n).decode("utf-8", errors="replace")
                    rec["xml"]       = xml
                    rec["props"]     = extract_xml_props(xml)
                    rec["operation"] = detect_operation(xml, filename)
                    break
            for n in names:
                if n.endswith(".groovy"):
                    try:
                        code = zf.read(n).decode("utf-8", errors="replace")
                        rec["groovy_scripts"].append({"file": n, "code": code})
                    except Exception:
                        pass
    except Exception as e:
        rec["parse_error"] = str(e)
    return rec


# ─── Index ─────────────────────────────────────────────────────────────────────

def load_index() -> List[Dict]:
    if INDEX_FILE.exists():
        try:
            return json.loads(INDEX_FILE.read_text())
        except Exception:
            pass
    return []


def save_index(records: List[Dict]) -> None:
    slim = []
    for r in records:
        s = {k: v for k, v in r.items() if k not in ("xml",)}
        s["xml_preview"]  = r.get("xml", "")[:600]
        slim.append(s)
    INDEX_FILE.write_text(json.dumps(slim, indent=2))


def find_best_match(index: List[Dict], operation: str,
                    entity_hint: str = "", path_hint: str = "") -> Optional[Dict]:
    op   = operation.upper()
    best = (0, None)
    for rec in index:
        score = 0
        if rec.get("operation","").upper() == op:                        score += 10
        eh = entity_hint.lower()
        if eh and eh in rec.get("props",{}).get("entity_name","").lower(): score += 5
        ph = path_hint.lower()
        if ph and ph in rec.get("props",{}).get("sender_path","").lower(): score += 3
        if score > best[0]:
            best = (score, rec)
    return best[1]


def load_full_zip(template_id: str) -> Optional[bytes]:
    p = TEMPLATE_DIR / f"{template_id}.zip"
    return p.read_bytes() if p.exists() else None


# ─── ZIP builder ───────────────────────────────────────────────────────────────

def build_zip(iflow_name: str, artifact_id: str,
               iflow_xml: str, groovy_code: str = "") -> bytes:
    slug = safe_slug(iflow_name)
    mf   = MANIFEST_TPL.format(name=iflow_name, aid=artifact_id)
    out  = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("META-INF/MANIFEST.MF", mf)
        zf.writestr(
            f"src/main/resources/scenarioflows/integrationflow/{slug}.iflw",
            iflow_xml)
        if groovy_code:
            zf.writestr(
                f"src/main/resources/script/{slug}_transform.groovy",
                groovy_code)
        zf.writestr(".project",
            f'<?xml version="1.0" encoding="UTF-8"?>'
            f'<projectDescription><n>{artifact_id}</n>'
            f'<comment>{iflow_name}</comment>'
            f'<natures><nature>com.sap.it.spc.webui.nature.IntegrationFlow'
            f'</nature></natures></projectDescription>')
    return out.getvalue()


def clone_zip(original: bytes, subs: List[Tuple[str,str]],
              new_name: str, groovy_code: str = "") -> bytes:
    out = io.BytesIO()
    groovy_done = False
    with zipfile.ZipFile(io.BytesIO(original), "r") as zin:
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                data  = zin.read(item.filename)
                fname = item.filename
                sfx   = Path(fname).suffix.lower()
                if sfx == ".iflw":
                    slug   = safe_slug(new_name)
                    parent = str(Path(fname).parent)
                    fname  = f"{parent}/{slug}.iflw" if parent != "." else f"{slug}.iflw"
                if sfx in TEXT_SUFFIXES:
                    try:
                        txt = data.decode("utf-8")
                        for old, new in subs:
                            if old and old != new:
                                txt = txt.replace(old, new)
                        data = txt.encode("utf-8")
                    except Exception:
                        pass
                if sfx == ".groovy" and groovy_code and not groovy_done:
                    slug2  = safe_slug(new_name)
                    parent2= str(Path(fname).parent)
                    fname  = f"{parent2}/{slug2}_transform.groovy"
                    data   = groovy_code.encode("utf-8")
                    groovy_done = True
                zout.writestr(fname, data)
            if groovy_code and not groovy_done:
                slug3 = safe_slug(new_name)
                zout.writestr(
                    f"src/main/resources/script/{slug3}_transform.groovy",
                    groovy_code.encode("utf-8"))
    return out.getvalue()


def get_groovy(op: str, entity: str = "",
               path: str = "", extra: str = "") -> str:
    pat = GROOVY_PATTERNS.get(op.upper(), GROOVY_PATTERNS["PASSTHROUGH"])
    pat = pat.replace("{ENTITY}", entity or "Entity")
    pat = pat.replace("{PATH}",   path   or "/api/v1/resource")
    if extra and extra.strip():
        lines = "\n".join(f"//   {l}" for l in extra.strip().splitlines())
        pat  += f"\n\n// ── Additional requirements ──────────────────────\n{lines}\n"
    return pat


# ═══════════════════════════════════════════════════════════════════════════════
# INTENT PARSER  — extract structured config from a chat message
# ═══════════════════════════════════════════════════════════════════════════════

def parse_intent(text: str) -> Dict:
    """
    Parse a free-text prompt and extract iFlow config parameters.
    Pure Python — no AI call needed for basic extraction.
    """
    t   = text.lower()
    cfg = {
        "operation":       "GET",
        "iflow_name":      "",
        "sender_path":     "",
        "entity_name":     "",
        "odata_address":   "",
        "sender_adapter":  "HTTPS",
        "receiver_adapter":"OData",
        "groovy_needed":   False,
        "groovy_req":      "",
        "mapping":         "1:1 root",
    }

    # Operation
    if any(w in t for w in ["create","post","insert","add new","new record"]): cfg["operation"] = "CREATE"
    elif any(w in t for w in ["update","put","patch","modify","change","edit"]): cfg["operation"] = "UPDATE"
    elif any(w in t for w in ["delete","remove","del "]):                         cfg["operation"] = "DELETE"
    else:                                                                          cfg["operation"] = "GET"

    # Groovy
    if any(w in t for w in ["groovy","script","transform","mapping","convert","filter"]):
        cfg["groovy_needed"] = True

    # Entity — look for A_Xxx or common entity names
    m = re.search(r'\bA_[A-Za-z]+\b', text)
    if m: cfg["entity_name"] = m.group(0)

    # Known SAP entities
    entity_map = {
        "purchase order": "A_PurchaseOrder",   "purchaseorder": "A_PurchaseOrder",
        "sales order":    "A_SalesOrder",       "salesorder":    "A_SalesOrder",
        "journal entry":  "A_JournalEntryItemBasic",
        "company code":   "A_CompanyCode",      "companycode":   "A_CompanyCode",
        "business partner":"A_BusinessPartner",
        "material":       "A_Product",
        "project":        "A_WorkPackage",
    }
    for phrase, entity in entity_map.items():
        if phrase in t and not cfg["entity_name"]:
            cfg["entity_name"] = entity
            break

    # Sender path — look for /Xxx/Yyy pattern
    m = re.search(r'(/[A-Za-z][A-Za-z0-9/]+)', text)
    if m: cfg["sender_path"] = m.group(1)
    elif cfg["entity_name"]:
        slug = cfg["entity_name"].replace("A_","").replace("ItemBasic","")
        cfg["sender_path"] = f"/{slug}/{cfg['operation'].title()}"

    # OData URL
    m = re.search(r'https?://\S+', text)
    if m: cfg["odata_address"] = m.group(0)

    # Adapter hints
    if "sftp"          in t: cfg["sender_adapter"] = "SFTP"
    elif "processdirect" in t: cfg["sender_adapter"] = "ProcessDirect"
    if "soap"          in t: cfg["receiver_adapter"] = "SOAP"
    elif "http"        in t and "https" not in t: cfg["receiver_adapter"] = "HTTP"

    # iFlow name — try to extract quoted name or build from entity+op
    m = re.search(r'"([^"]+)"', text) or re.search(r"'([^']+)'", text)
    if m:
        cfg["iflow_name"] = m.group(1)
    elif cfg["entity_name"]:
        entity_short = cfg["entity_name"].replace("A_","")
        cfg["iflow_name"] = f"{cfg['operation'].title()}_{entity_short}_iFlow"
    else:
        cfg["iflow_name"] = f"{cfg['operation'].title()}_iFlow"

    return cfg


# ═══════════════════════════════════════════════════════════════════════════════
# OLLAMA
# ═══════════════════════════════════════════════════════════════════════════════

def ollama_ok() -> bool:
    try:
        r = requests.get(f"{OLLAMA_HOST}/api/tags", timeout=2)
        return r.status_code == 200
    except Exception:
        return False


def ollama_stream(prompt: str) -> str:
    """Stream from Ollama, returning complete text."""
    full = ""
    try:
        resp = requests.post(
            f"{OLLAMA_HOST}/api/generate",
            json={"model": OLLAMA_MODEL, "prompt": prompt, "stream": True},
            stream=True, timeout=120,
        )
        for line in resp.iter_lines():
            if not line: continue
            try:
                d     = json.loads(line)
                token = d.get("response", "")
                full += token
                if d.get("done"): break
            except Exception:
                continue
    except Exception as e:
        full = f"[Ollama error: {e}]"
    return full


# ═══════════════════════════════════════════════════════════════════════════════
# GENERATE iFlow  — the core action called from chat
# ═══════════════════════════════════════════════════════════════════════════════

def generate_iflow(cfg: Dict, index: List[Dict]) -> Tuple[bytes, str, str]:
    """
    Returns (zip_bytes, groovy_code, summary_text)
    """
    op          = cfg["operation"]
    iflow_name  = cfg["iflow_name"]  or f"{op}_iFlow"
    artifact_id = safe_slug(iflow_name)
    sender_path = cfg["sender_path"] or f"/{safe_slug(iflow_name.lower())}"
    entity_name = cfg["entity_name"] or "A_Entity"
    odata_addr  = cfg["odata_address"]

    # Find best template
    matched    = find_best_match(index, op, entity_name, sender_path)
    using_skel = matched is None
    tmpl_name  = matched["name"] if matched else f"Built-in {op} skeleton"
    tmpl_src   = "uploaded template" if matched else "built-in skeleton"

    # Groovy
    groovy_code = ""
    if cfg.get("groovy_needed"):
        groovy_code = get_groovy(op, entity_name, sender_path, cfg.get("groovy_req",""))

    # Build ZIP
    if using_skel:
        xml = SKELETONS.get(op, SKELETONS["GET"])
        for ph, val in [
            ("%%IFLOW_NAME%%",   iflow_name),
            ("%%SENDER_PATH%%",  sender_path),
            ("%%ENTITY_NAME%%",  entity_name),
            ("%%ODATA_ADDRESS%%",odata_addr),
        ]:
            xml = xml.replace(ph, val)
        zip_bytes = build_zip(iflow_name, artifact_id, xml, groovy_code)
    else:
        original = load_full_zip(matched["id"])
        if original is None:
            # Fallback to skeleton if ZIP missing from disk
            xml = SKELETONS.get(op, SKELETONS["GET"])
            for ph, val in [("%%IFLOW_NAME%%",iflow_name),("%%SENDER_PATH%%",sender_path),
                            ("%%ENTITY_NAME%%",entity_name),("%%ODATA_ADDRESS%%",odata_addr)]:
                xml = xml.replace(ph, val)
            zip_bytes = build_zip(iflow_name, artifact_id, xml, groovy_code)
            tmpl_src  = "built-in skeleton (template ZIP not on disk)"
        else:
            p = matched.get("props", {})
            subs = [
                (matched.get("name",""),                   iflow_name),
                (matched.get("id",""),                     artifact_id),
                (p.get("iflow_display_name",""),           iflow_name),
                (p.get("sender_path",""),                  sender_path),
                (p.get("entity_name",""),                  entity_name),
                (p.get("odata_address",""),                odata_addr),
                ("%%IFLOW_NAME%%",  iflow_name),
                ("%%SENDER_PATH%%", sender_path),
                ("%%ENTITY_NAME%%", entity_name),
            ]
            zip_bytes = clone_zip(original, subs, iflow_name, groovy_code)

    summary = f"""✅ **iFlow generated successfully**

| Field | Value |
|---|---|
| **iFlow Name** | `{iflow_name}` |
| **Artifact ID** | `{artifact_id}` |
| **Operation** | `{op}` |
| **Sender Path** | `{sender_path}` |
| **Entity** | `{entity_name}` |
| **OData URL** | `{odata_addr or "(not set)"}` |
| **Template Used** | {tmpl_name} |
| **Source** | {tmpl_src} |
| **Groovy** | {"✓ Included (" + op + " pattern)" if groovy_code else "Not included"} |
| **ZIP Size** | {round(len(zip_bytes)/1024,1)} KB |"""

    return zip_bytes, groovy_code, summary


# ═══════════════════════════════════════════════════════════════════════════════
# PAGE CONFIG & STYLES
# ═══════════════════════════════════════════════════════════════════════════════

st.set_page_config(
    page_title="SAP CPI iFlow Generator",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
/* ── Global dark theme ───────────────────────────────────────────── */
.stApp { background: #0d1117; color: #e6edf3; font-family: 'Segoe UI', sans-serif; }
section[data-testid="stSidebar"] {
    background: #161b22 !important;
    border-right: 1px solid #30363d;
}
/* ── Chat messages ───────────────────────────────────────────────── */
.msg-user {
    display: flex; justify-content: flex-end; margin: 12px 0;
}
.msg-user .bubble {
    background: #1f6feb; color: #fff; border-radius: 18px 18px 4px 18px;
    padding: 12px 18px; max-width: 75%; font-size: 14px; line-height: 1.5;
}
.msg-bot {
    display: flex; justify-content: flex-start; margin: 12px 0; gap: 10px;
}
.msg-bot .avatar {
    width: 32px; height: 32px; background: linear-gradient(135deg,#238636,#1f6feb);
    border-radius: 50%; display: flex; align-items: center; justify-content: center;
    font-size: 16px; flex-shrink: 0;
}
.msg-bot .bubble {
    background: #161b22; border: 1px solid #30363d;
    border-radius: 4px 18px 18px 18px;
    padding: 14px 18px; max-width: 85%; font-size: 14px; line-height: 1.6;
}
/* ── Sidebar chips ───────────────────────────────────────────────── */
.chip {
    display: inline-block; padding: 3px 10px; border-radius: 12px;
    font-size: 11px; font-weight: 700; margin: 2px;
}
.chip-get    { background:#1a3b1a; color:#3fb950; border:1px solid #238636; }
.chip-create { background:#1f3a5f; color:#58a6ff; border:1px solid #388bfd; }
.chip-update { background:#3b2a1a; color:#d29922; border:1px solid #9e6a03; }
.chip-delete { background:#3b1a1a; color:#f85149; border:1px solid #da3633; }
/* ── Buttons ─────────────────────────────────────────────────────── */
.stButton > button {
    background: #21262d; color: #e6edf3; border: 1px solid #30363d;
    border-radius: 8px; font-weight: 500; transition: all 0.2s;
}
.stButton > button:hover { background: #30363d; border-color: #58a6ff; }
/* ── Input ───────────────────────────────────────────────────────── */
.stTextInput > div > div > input,
.stTextArea  > div > div > textarea {
    background: #21262d !important; border: 1px solid #30363d !important;
    color: #e6edf3 !important; border-radius: 8px !important;
}
/* ── Expander ────────────────────────────────────────────────────── */
div[data-testid="stExpander"] {
    background: #161b22; border: 1px solid #30363d; border-radius: 8px;
}
/* ── Progress ────────────────────────────────────────────────────── */
.stProgress > div > div { background: #1f6feb; }
/* ── Tables ──────────────────────────────────────────────────────── */
.stDataFrame { border: 1px solid #30363d; border-radius: 8px; }
/* ── Metrics ─────────────────────────────────────────────────────── */
div[data-testid="metric-container"] {
    background: #161b22; border: 1px solid #30363d;
    border-radius: 8px; padding: 12px;
}
div[data-testid="metric-container"] label { color: #8b949e !important; }
div[data-testid="stMetricValue"] { color: #58a6ff !important; }
/* ── Status boxes ─────────────────────────────────────────────────── */
.sbox { border-radius:8px; padding:12px 16px; margin:6px 0; font-size:13px; }
.sbox-ok  { background:#1a3b1a; border:1px solid #238636; color:#3fb950; }
.sbox-warn{ background:#3b2a1a; border:1px solid #9e6a03; color:#d29922; }
.sbox-info{ background:#1f3a5f; border:1px solid #388bfd; color:#58a6ff; }
/* ── Hide Streamlit decorations ──────────────────────────────────── */
#MainMenu { visibility: hidden; }
footer    { visibility: hidden; }
header    { visibility: hidden; }
/* ── Chat input pinned at bottom ─────────────────────────────────── */
.chat-input-area {
    position: sticky; bottom: 0; background: #0d1117;
    padding: 12px 0 8px; border-top: 1px solid #21262d;
}
</style>
""", unsafe_allow_html=True)

# ═══════════════════════════════════════════════════════════════════════════════
# SESSION STATE
# ═══════════════════════════════════════════════════════════════════════════════

if "messages"   not in st.session_state: st.session_state.messages   = []
if "last_zip"   not in st.session_state: st.session_state.last_zip   = None
if "last_fname" not in st.session_state: st.session_state.last_fname = None
if "last_groovy"not in st.session_state: st.session_state.last_groovy= None
if "pending_cfg"not in st.session_state: st.session_state.pending_cfg= None

# ═══════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ═══════════════════════════════════════════════════════════════════════════════

with st.sidebar:
    st.markdown("## ⚡ CPI iFlow Generator")
    st.markdown("---")
    mode = st.radio(
        "Mode",
        ["💬 Chat & Generate", "📁 Upload iFlows", "🧠 Train Index"],
        label_visibility="collapsed",
    )
    st.markdown("---")

    # ── Stats ─────────────────────────────────────────────────────────────────
    index    = load_index()
    n_zips   = len(list(TEMPLATE_DIR.glob("*.zip")))
    op_cnts  = defaultdict(int)
    for r in index: op_cnts[r.get("operation","?")] += 1

    st.markdown("**Library**")
    c1, c2 = st.columns(2)
    c1.metric("ZIPs",    n_zips)
    c2.metric("Trained", len(index))

    if index:
        chips = ""
        for op, cnt in sorted(op_cnts.items()):
            cls = {"GET":"chip-get","CREATE":"chip-create",
                   "UPDATE":"chip-update","DELETE":"chip-delete"}.get(op,"chip-get")
            chips += f'<span class="chip {cls}">{op} {cnt}</span>'
        st.markdown(chips, unsafe_allow_html=True)

    st.markdown("---")

    # ── Ollama ────────────────────────────────────────────────────────────────
    up = ollama_ok()
    if up:
        st.markdown(
            f'<div class="sbox sbox-ok">● Ollama online<br>'
            f'<small style="opacity:.7">{OLLAMA_MODEL}</small></div>',
            unsafe_allow_html=True)
    else:
        st.markdown(
            '<div class="sbox sbox-warn">● Ollama offline<br>'
            '<small style="opacity:.7">Python fallback active</small></div>',
            unsafe_allow_html=True)

    st.markdown("---")

    # ── Quick actions ─────────────────────────────────────────────────────────
    st.markdown("**Quick prompts**")
    quick = [
        "GET Purchase Orders from S/4HANA with Groovy",
        "CREATE Sales Order iFlow",
        "UPDATE Project Elements iFlow",
        "DELETE Purchase Order iFlow",
        "GET Journal Entry with entity A_JournalEntryItemBasic",
    ]
    for q in quick:
        if st.button(q, key=f"q_{q[:20]}", use_container_width=True):
            st.session_state.messages.append({"role":"user","content":q})
            st.session_state.pending_cfg = parse_intent(q)
            st.rerun()

    st.markdown("---")
    if st.button("🗑 Clear chat", use_container_width=True):
        st.session_state.messages = []
        st.session_state.last_zip = None
        st.rerun()


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN AREA — CHAT
# ═══════════════════════════════════════════════════════════════════════════════

if mode == "💬 Chat & Generate":

    st.markdown("### SAP CPI iFlow Generator")
    st.caption("Describe any iFlow in plain English — GET, CREATE, UPDATE, or DELETE. "
               "Mention entity names, adapter types, Groovy requirements, or just the SAP object.")

    # ── Render chat history ───────────────────────────────────────────────────
    chat_area = st.container()
    with chat_area:
        for msg in st.session_state.messages:
            if msg["role"] == "user":
                st.markdown(
                    f'<div class="msg-user"><div class="bubble">{msg["content"]}</div></div>',
                    unsafe_allow_html=True)
            else:
                content = msg["content"]
                st.markdown(
                    f'<div class="msg-bot"><div class="avatar">⚡</div>'
                    f'<div class="bubble">{content}</div></div>',
                    unsafe_allow_html=True)
                # Show download if this message has an attached ZIP
                if msg.get("has_zip") and msg.get("zip_key"):
                    key = msg["zip_key"]
                    if key in st.session_state:
                        st.download_button(
                            label=f"⬇ Download {msg.get('zip_fname','iflow.zip')}",
                            data=st.session_state[key],
                            file_name=msg.get("zip_fname","iflow.zip"),
                            mime="application/zip",
                            key=f"dl_{key}",
                        )

    # ── Process any pending message (from quick buttons) ─────────────────────
    if st.session_state.pending_cfg is not None:
        cfg    = st.session_state.pending_cfg
        st.session_state.pending_cfg = None

        index  = load_index()
        with st.spinner("Generating your iFlow…"):
            zip_bytes, groovy_code, summary = generate_iflow(cfg, index)

        fname  = f"{safe_slug(cfg['iflow_name'])}.zip"
        zkey   = f"zip_{int(time.time()*1000)}"
        st.session_state[zkey] = zip_bytes

        bot_reply = summary
        if groovy_code:
            bot_reply += f"\n\n**Groovy script included** — {cfg['operation']} pattern"

        st.session_state.messages.append({
            "role":     "assistant",
            "content":  bot_reply,
            "has_zip":  True,
            "zip_key":  zkey,
            "zip_fname":fname,
        })
        st.rerun()

    # ── Chat input ────────────────────────────────────────────────────────────
    st.markdown('<div class="chat-input-area">', unsafe_allow_html=True)
    with st.form(key="chat_form", clear_on_submit=True):
        col_inp, col_btn = st.columns([8, 1])
        with col_inp:
            user_input = st.text_input(
                "prompt",
                placeholder="e.g.  Create a GET iFlow to fetch Purchase Orders from S/4HANA with Groovy transformation",
                label_visibility="collapsed",
            )
        with col_btn:
            submitted = st.form_submit_button("Send", use_container_width=True)
    st.markdown('</div>', unsafe_allow_html=True)

    if submitted and user_input.strip():
        prompt = user_input.strip()
        st.session_state.messages.append({"role":"user","content":prompt})

        # Parse intent from prompt
        cfg   = parse_intent(prompt)
        index = load_index()

        # Stream Ollama narrative if available
        thinking_placeholder = st.empty()
        if ollama_ok():
            llm_prompt = f"""You are an SAP CPI expert assistant. The user wants to create an iFlow.

User message: {prompt}

Extracted config:
- Operation   : {cfg['operation']}
- iFlow Name  : {cfg['iflow_name']}
- Sender Path : {cfg['sender_path']}
- Entity      : {cfg['entity_name']}
- Groovy      : {'yes' if cfg['groovy_needed'] else 'no'}

Reply in 3-4 short sentences:
1. Confirm what iFlow you are building
2. Mention which template will be used (best match from {len(index)} trained iFlows)
3. Note any Groovy script being attached
4. Say the ZIP is being generated

Be concise, technical, and professional. No bullet points."""
            with thinking_placeholder:
                with st.spinner("Thinking…"):
                    narrative = ollama_stream(llm_prompt)
        else:
            narrative = (
                f"Generating a **{cfg['operation']}** iFlow named `{cfg['iflow_name']}`. "
                f"Sender: `{cfg['sender_path']}` → Entity: `{cfg['entity_name']}`. "
                + ("Groovy transformation script included. " if cfg['groovy_needed'] else "")
                + f"Searching {len(index)} trained templates for best match…"
            )
        thinking_placeholder.empty()

        # Generate the iFlow
        with st.spinner("Building your iFlow ZIP…"):
            zip_bytes, groovy_code, summary = generate_iflow(cfg, index)

        # Save zip to session
        fname = f"{safe_slug(cfg['iflow_name'])}.zip"
        zkey  = f"zip_{int(time.time()*1000)}"
        st.session_state[zkey] = zip_bytes

        full_reply = narrative + "\n\n" + summary
        if groovy_code:
            full_reply += f"\n\n**Groovy script:** `{cfg['operation']}` pattern — filled with entity `{cfg['entity_name']}`"

        st.session_state.messages.append({
            "role":     "assistant",
            "content":  full_reply,
            "has_zip":  True,
            "zip_key":  zkey,
            "zip_fname":fname,
        })

        # Save to outputs folder
        (OUTPUT_DIR / fname).write_bytes(zip_bytes)
        st.rerun()

    # ── Welcome message ───────────────────────────────────────────────────────
    if not st.session_state.messages:
        st.markdown("""
<div style="text-align:center;padding:60px 20px;color:#8b949e;">
  <div style="font-size:48px;margin-bottom:16px;">⚡</div>
  <div style="font-size:20px;font-weight:600;color:#e6edf3;margin-bottom:8px;">
    SAP CPI iFlow Intelligence Generator
  </div>
  <div style="font-size:14px;margin-bottom:24px;">
    Describe any iFlow in plain English. Upload your 200+ iFlows in the sidebar first.
  </div>
  <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
    <span style="background:#21262d;border:1px solid #30363d;border-radius:8px;padding:8px 14px;font-size:13px;">
      💬 "GET Purchase Orders from S/4HANA with Groovy"
    </span>
    <span style="background:#21262d;border:1px solid #30363d;border-radius:8px;padding:8px 14px;font-size:13px;">
      💬 "Create Sales Order iFlow"
    </span>
    <span style="background:#21262d;border:1px solid #30363d;border-radius:8px;padding:8px 14px;font-size:13px;">
      💬 "DELETE iFlow for A_PurchaseOrder with Groovy"
    </span>
  </div>
</div>
""", unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════════════════════════
# SIDEBAR MODE — UPLOAD
# ═══════════════════════════════════════════════════════════════════════════════

elif mode == "📁 Upload iFlows":
    st.markdown("## 📁 Upload iFlow Template Library")
    st.info("One-time activity. Drop your entire folder of 200+ iFlow ZIPs here at once. "
            "Operation type (GET/CREATE/UPDATE/DELETE) is auto-detected from each ZIP's XML.")

    uploaded = st.file_uploader(
        "Drop ALL your iFlow ZIPs here",
        type=["zip"], accept_multiple_files=True,
        help="Upload your full library at once — mixed operations supported"
    )

    if uploaded:
        st.success(f"{len(uploaded)} file(s) selected.")
        if st.button("⬆ Upload to Template Library", type="primary", use_container_width=True):
            counts = defaultdict(int)
            errors = []
            bar    = st.progress(0)
            status = st.empty()

            for i, f in enumerate(uploaded):
                bar.progress((i+1)/len(uploaded))
                status.text(f"Saving {f.name}…")
                try:
                    zb  = f.read()
                    rec = parse_single_zip(zb, f.name)
                    tid = safe_slug(Path(f.name).stem)
                    (TEMPLATE_DIR / f"{tid}.zip").write_bytes(zb)
                    meta = {k:v for k,v in rec.items() if k not in ("xml","groovy_scripts")}
                    meta["xml_preview"] = rec.get("xml","")[:400]
                    (TEMPLATE_DIR / f"{tid}.meta.json").write_text(
                        json.dumps(meta, indent=2))
                    counts[rec["operation"]] += 1
                except Exception as e:
                    errors.append(f"{f.name}: {e}")

            bar.empty(); status.empty()
            total_ok = sum(counts.values())
            st.success(f"✓ {total_ok} iFlows uploaded")

            cols = st.columns(4)
            for col, op in zip(cols, ["GET","CREATE","UPDATE","DELETE"]):
                col.metric(op, counts[op])

            if errors:
                with st.expander(f"⚠ {len(errors)} error(s)"):
                    for e in errors: st.text(e)

            st.info("👉 Switch to **🧠 Train Index** next to build the searchable pattern index.")

    # Show existing library
    existing = sorted(TEMPLATE_DIR.glob("*.zip"))
    if existing:
        st.markdown(f"---\n**Library: {len(existing)} ZIP(s) stored**")
        rows = []
        for z in existing[:100]:
            mp = TEMPLATE_DIR / f"{z.stem}.meta.json"
            meta = {}
            if mp.exists():
                try: meta = json.loads(mp.read_text())
                except: pass
            rows.append({
                "Name":      meta.get("name", z.stem),
                "Operation": meta.get("operation","?"),
                "Entity":    (meta.get("props") or {}).get("entity_name",""),
                "Sender Path":(meta.get("props") or {}).get("sender_path",""),
                "Groovy":    "Yes" if meta.get("groovy_files") else "No",
                "Size (KB)": round(z.stat().st_size/1024, 1),
            })
        if rows:
            import pandas as pd
            st.dataframe(pd.DataFrame(rows), use_container_width=True, height=400)
        if len(existing) > 100:
            st.caption(f"…and {len(existing)-100} more not shown")


# ═══════════════════════════════════════════════════════════════════════════════
# SIDEBAR MODE — TRAIN
# ═══════════════════════════════════════════════════════════════════════════════

elif mode == "🧠 Train Index":
    st.markdown("## 🧠 Train — Build Pattern Index")
    st.info(
        "Reads every uploaded ZIP and extracts: adapter types, sender paths, entity names, "
        "OData URLs, Groovy scripts, mapping presence. "
        "Builds `trained_index/iflow_index.json` used at generation time. "
        "Re-run whenever you add new ZIPs."
    )

    zips = list(TEMPLATE_DIR.glob("*.zip"))
    if not zips:
        st.warning("No ZIPs found. Complete Upload step first.")
        st.stop()

    st.metric("ZIPs ready to train", len(zips))

    if st.button("🧠 Train All iFlows Now", type="primary", use_container_width=True):
        records     = []
        errors      = []
        op_cnts     = defaultdict(int)
        groovy_cnt  = 0
        mapping_cnt = 0
        bar    = st.progress(0)
        status = st.empty()
        log    = st.expander("Training log", expanded=True)

        for i, zpath in enumerate(zips):
            bar.progress((i+1)/len(zips))
            status.text(f"[{i+1}/{len(zips)}] {zpath.name}")
            try:
                zb  = zpath.read_bytes()
                rec = parse_single_zip(zb, zpath.name)
                rec["id"] = zpath.stem
                records.append(rec)
                op_cnts[rec["operation"]] += 1
                if rec["groovy_scripts"]:  groovy_cnt  += 1
                if rec["has_mapping"]:     mapping_cnt += 1
                with log:
                    p = rec.get("props",{})
                    st.markdown(
                        f"`{rec['operation']}` **{rec['name']}** — "
                        f"entity: `{p.get('entity_name','–')}` | "
                        f"path: `{p.get('sender_path','–')}` | "
                        f"groovy: {len(rec['groovy_scripts'])}"
                    )
            except Exception as e:
                errors.append(f"{zpath.name}: {e}")

        save_index(records)
        bar.empty(); status.empty()

        st.success(f"✓ Training complete — {len(records)} iFlows indexed")

        c1, c2, c3, c4, c5, c6 = st.columns(6)
        c1.metric("Total",   len(records))
        c2.metric("GET",     op_cnts["GET"])
        c3.metric("CREATE",  op_cnts["CREATE"])
        c4.metric("UPDATE",  op_cnts["UPDATE"])
        c5.metric("DELETE",  op_cnts["DELETE"])
        c6.metric("w/Groovy",groovy_cnt)

        if mapping_cnt:
            st.info(f"{mapping_cnt} iFlows have message mapping (.mmap) files")

        if errors:
            with st.expander(f"⚠ {len(errors)} error(s)"):
                for e in errors: st.text(e)

        st.success("👉 Switch to **💬 Chat & Generate** — your 200+ iFlows are now trained!")

    # Show current index status
    if INDEX_FILE.exists():
        idx = load_index()
        st.markdown(f"---\n**Current index:** {len(idx)} records · `{INDEX_FILE}`")

        # Show Groovy patterns extracted
        groovy_all = []
        for rec in idx:
            for s in rec.get("groovy_scripts",[]):
                groovy_all.append({
                    "iFlow":     rec["name"],
                    "Operation": rec["operation"],
                    "Script":    Path(s["file"]).name,
                })
        if groovy_all:
            st.markdown(f"**{len(groovy_all)} Groovy scripts extracted from your iFlows:**")
            import pandas as pd
            st.dataframe(pd.DataFrame(groovy_all), use_container_width=True, height=250)

        if st.button("🗑 Clear index and retrain from scratch"):
            INDEX_FILE.unlink()
            st.rerun()
