# SAP CPI iFlow Intelligence Generator — Streamlit App

Full working 4-phase application. No API keys. No cloud. Runs on your machine.

## Quick Start

```bash
# Optional: Install and start Ollama for AI narrative output
# https://ollama.com/download
ollama pull llama3.2

# Run the app
chmod +x run.sh
./run.sh

# Open browser → http://localhost:8501
```

Or manually:
```bash
pip install streamlit requests pandas
streamlit run app.py
```

---

## The 4 Phases

### Phase 1 — Upload (one-time)
- Drop all 200+ iFlow ZIPs onto the upload screen at once
- Each ZIP is saved to `template_library/`
- Operation type auto-detected from XML (GET / CREATE / UPDATE / DELETE)
- Shows per-file summary table after upload

### Phase 2 — Train
- Reads every ZIP in `template_library/`
- Extracts: sender path, entity name, OData URL, adapter types, Groovy scripts, mapping presence
- Builds `trained_index/iflow_index.json` — searchable pattern index
- Run once after upload; re-run when you add new ZIPs

### Phase 3 — Generate
- Chat-style prompt input + configuration form
- Finds best matching template from your trained index (scores by operation + entity + path)
- If no match: falls back to built-in skeleton iFlow
- Applies Python XML substitution on the matched template
- Attaches Groovy script from pattern library if requested
- Download as valid SAP CPI importable ZIP

### Phase 4 — Groovy Studio
- Generate any GET / CREATE / UPDATE / DELETE / PASSTHROUGH Groovy script instantly
- Browse all Groovy scripts extracted from YOUR actual uploaded iFlows
- Download individual scripts

---

## Files & Folders

```
cpi-streamlit/
├── app.py                    ← Complete application (single file)
├── requirements.txt
├── run.sh
├── template_library/         ← Your uploaded iFlow ZIPs (created on first run)
│   ├── my_iflow.zip
│   ├── my_iflow.meta.json
│   └── ...
├── trained_index/
│   └── iflow_index.json      ← Built by Phase 2 training
└── output_zips/              ← Generated iFlows saved here
    └── Get_PurchaseOrder.zip
```

---

## Ollama (optional)
If Ollama is running, the generator streams a natural language narrative
describing the iFlow being built. If Ollama is offline, a Python
rule-based summary is shown instead — generation still works perfectly.

Set model: `OLLAMA_MODEL=mistral streamlit run app.py`
