#!/bin/bash
echo "Installing dependencies..."
pip install -r requirements.txt -q --break-system-packages 2>/dev/null || pip install -r requirements.txt -q

echo ""
echo "Starting SAP CPI iFlow Generator..."
echo "Open: http://localhost:8501"
echo ""

streamlit run app.py \
  --server.port 8501 \
  --server.headless true \
  --theme.base dark \
  --theme.primaryColor "#1f6feb" \
  --theme.backgroundColor "#0d1117" \
  --theme.secondaryBackgroundColor "#161b22" \
  --theme.textColor "#e6edf3"
