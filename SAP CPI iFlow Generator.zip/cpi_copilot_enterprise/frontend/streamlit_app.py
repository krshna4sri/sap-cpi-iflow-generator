from pathlib import Path
import requests
import streamlit as st

API = st.sidebar.text_input("Backend URL", "http://localhost:8000/api")

st.title("SAP CPI Copilot Enterprise")
st.caption("Batch-train on exported CPI packages, retrieve the closest template, generate a cloned iFlow, and optionally deploy to CPI.")

tab1, tab2, tab3 = st.tabs(["Train", "Generate", "Deploy"])

with tab1:
    files = st.file_uploader("Upload one or more CPI export ZIPs", type=["zip"], accept_multiple_files=True)
    if st.button("Train / Index Templates", type="primary"):
        if not files:
            st.warning("Upload at least one ZIP.")
        else:
            resp = requests.post(
                f"{API}/train",
                files=[("files", (f.name, f.getvalue(), "application/zip")) for f in files],
                timeout=1800
            )
            st.json(resp.json())
    if st.button("Show Indexed Templates"):
        st.json(requests.get(f"{API}/templates", timeout=120).json())

with tab2:
    prompt = st.text_area("Prompt", "Create HTTPS to ODATA GET iFlow with Groovy timestamp header and root mapping")
    iflow_name = st.text_input("iFlow Name", "Generated Enterprise Flow")
    artifact_id = st.text_input("Artifact ID", "Generated_Enterprise_Flow")
    sender_name = st.text_input("Sender Name", "Sender_1")
    receiver_name = st.text_input("Receiver Name", "Receiver_1")
    add_groovy = st.checkbox("Add Groovy", value=True)
    add_mapping = st.checkbox("Add Mapping Placeholder", value=True)

    if st.button("Generate iFlow", type="primary"):
        payload = {
            "prompt": prompt,
            "iflow_name": iflow_name,
            "artifact_id": artifact_id,
            "sender_name": sender_name,
            "receiver_name": receiver_name,
            "auto_add_groovy": add_groovy,
            "inject_mapping": add_mapping,
        }
        resp = requests.post(f"{API}/generate", json=payload, timeout=1800)
        data = resp.json()
        st.json(data)
        if "generation_id" in data:
            exp = requests.get(f"{API}/export/{data['generation_id']}", timeout=120).json()
            zip_path = exp["zip_path"]
            with open(zip_path, "rb") as fh:
                st.download_button("Download Generated ZIP", fh.read(), file_name=Path(zip_path).name, mime="application/zip")

with tab3:
    generation_id = st.text_input("Generation ID")
    tenant_url = st.text_input("Tenant URL")
    package_id = st.text_input("Package ID")
    auth_type = st.selectbox("Auth Type", ["basic", "oauth"])
    payload = {
        "generation_id": generation_id,
        "tenant_url": tenant_url,
        "package_id": package_id,
        "auth_type": auth_type,
    }
    if auth_type == "basic":
        payload["username"] = st.text_input("Username")
        payload["password"] = st.text_input("Password", type="password")
    else:
        payload["client_id"] = st.text_input("Client ID")
        payload["client_secret"] = st.text_input("Client Secret", type="password")
        payload["token_url"] = st.text_input("Token URL")

    if st.button("Deploy"):
        st.json(requests.post(f"{API}/deploy", json=payload, timeout=600).json())
