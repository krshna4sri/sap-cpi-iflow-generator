from __future__ import annotations
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field

class TemplateSummary(BaseModel):
    template_id: str
    source_export: str
    resource_id: str
    resource_name: str
    display_name: str = ""
    unique_id: str = ""
    description: str = ""
    operation: str = "UNKNOWN"
    sender_types: List[str] = Field(default_factory=list)
    receiver_types: List[str] = Field(default_factory=list)
    methods: List[str] = Field(default_factory=list)
    groovy_files: List[str] = Field(default_factory=list)
    mapping_files: List[str] = Field(default_factory=list)
    script_signatures: List[str] = Field(default_factory=list)
    score_terms: List[str] = Field(default_factory=list)
    package_structure: Dict[str, str] = Field(default_factory=dict)
    raw_files: List[str] = Field(default_factory=list)

class GenerateRequest(BaseModel):
    prompt: str
    iflow_name: str
    artifact_id: Optional[str] = None
    sender_name: Optional[str] = None
    receiver_name: Optional[str] = None
    preferred_sender: Optional[str] = None
    preferred_receiver: Optional[str] = None
    auto_add_groovy: bool = True
    inject_mapping: bool = True

class GenerateResponse(BaseModel):
    generation_id: str
    template_id: str
    matched_template_name: str
    parsed_intent: Dict[str, Any]
    output_zip: str
    top_matches: List[Dict[str, Any]] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    created_files: List[str] = Field(default_factory=list)

class DeployRequest(BaseModel):
    generation_id: str
    tenant_url: str
    package_id: str
    auth_type: str
    username: Optional[str] = None
    password: Optional[str] = None
    client_id: Optional[str] = None
    client_secret: Optional[str] = None
    token_url: Optional[str] = None

class HealthResponse(BaseModel):
    status: str
    indexed_templates: int
