from fastapi import FastAPI
from app.api.routes import router

app = FastAPI(title="SAP CPI Copilot Enterprise")
app.include_router(router, prefix="/api")
