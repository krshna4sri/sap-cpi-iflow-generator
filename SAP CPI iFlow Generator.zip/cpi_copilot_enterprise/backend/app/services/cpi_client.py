from __future__ import annotations
import base64
from pathlib import Path
import requests

class CPIClient:
    def deploy(self, tenant_url: str, package_id: str, zip_path: Path, auth: dict) -> dict:
        s = requests.Session()
        if auth["type"] == "basic":
            s.auth = (auth["username"], auth["password"])
        else:
            token = self._oauth(auth["token_url"], auth["client_id"], auth["client_secret"])
            s.headers.update({"Authorization": f"Bearer {token}"})

        meta = s.get(tenant_url.rstrip("/") + "/api/v1/$metadata", headers={"x-csrf-token": "fetch"}, timeout=60)
        meta.raise_for_status()
        csrf = meta.headers.get("x-csrf-token", "")
        payload = {
            "Name": zip_path.stem,
            "PackageId": package_id,
            "ArtifactContent": base64.b64encode(zip_path.read_bytes()).decode("utf-8"),
        }
        hdr = {"x-csrf-token": csrf, "Content-Type": "application/json"}
        create = s.post(tenant_url.rstrip("/") + "/api/v1/IntegrationDesigntimeArtifacts", json=payload, headers=hdr, timeout=120)
        create.raise_for_status()
        return {"create_status": create.status_code, "response": create.text[:1000]}

    def _oauth(self, token_url: str, client_id: str, client_secret: str) -> str:
        r = requests.post(token_url, data={"grant_type": "client_credentials"}, auth=(client_id, client_secret), timeout=60)
        r.raise_for_status()
        return r.json()["access_token"]
