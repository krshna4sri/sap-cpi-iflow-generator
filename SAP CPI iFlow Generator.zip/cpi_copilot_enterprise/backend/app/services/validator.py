from __future__ import annotations
from pathlib import Path
from typing import List
from xml.etree import ElementTree as ET

def validate_iflow_folder(root: Path) -> List[str]:
    warnings: List[str] = []
    files = [str(p.relative_to(root)).replace("\\","/") for p in root.rglob("*") if p.is_file()]
    if not any(f.endswith(".iflw") for f in files):
        warnings.append("No .iflw file found in generated package")
    if not any("META-INF/MANIFEST.MF" in f for f in files):
        warnings.append("MANIFEST.MF not found")
    for iflow in root.rglob("*.iflw"):
        try:
            ET.fromstring(iflow.read_text(encoding="utf-8", errors="ignore"))
        except Exception as exc:
            warnings.append(f"iFlow XML parse warning: {exc}")
    for groovy in root.rglob("*.groovy"):
        txt = groovy.read_text(encoding="utf-8", errors="ignore")
        if "processData" not in txt:
            warnings.append(f"Groovy missing processData: {groovy.name}")
    return warnings
