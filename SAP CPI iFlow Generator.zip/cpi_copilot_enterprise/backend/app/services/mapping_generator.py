from __future__ import annotations
import re

def safe_name(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9_]+", "_", text).strip("_") or "mapping"

def esc(text: str) -> str:
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

def build_mapping(intent: dict) -> tuple[str, str]:
    name = safe_name(intent.get("iflow_name", "generated_mapping")) + ".mmap"
    req = esc(intent.get("mapping_requirement", "1:1 root mapping"))
    content = f'''<?xml version="1.0" encoding="UTF-8"?>
<mapping>
  <summary>{req}</summary>
  <source root="SourceRoot"/>
  <target root="TargetRoot"/>
  <rule type="placeholder">Review in CPI graphical mapping editor.</rule>
</mapping>
'''
    return name, content
