from __future__ import annotations
import base64
import json
import re
import shutil
import uuid
import zipfile
from pathlib import Path
from typing import List, Dict
from app.core.config import OUTER_EXPORT_DIR, TEMPLATE_DIR
from app.models import TemplateSummary

KNOWN_ADAPTERS = ["HTTPS", "HTTP", "ODATA", "SOAP", "SFTP", "FTP", "PROCESSDIRECT", "IDOC", "MAIL", "XI"]
KNOWN_METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE"]

class ExportParser:
    def ingest_export(self, outer_zip: Path) -> List[TemplateSummary]:
        export_id = uuid.uuid4().hex[:10]
        export_dir = OUTER_EXPORT_DIR / export_id
        export_dir.mkdir(parents=True, exist_ok=True)
        outer_copy = export_dir / outer_zip.name
        shutil.copy2(outer_zip, outer_copy)

        with zipfile.ZipFile(outer_copy, "r") as zf:
            zf.extractall(export_dir / "expanded")

        resource_meta = self._load_resource_metadata(export_dir / "expanded")
        summaries: List[TemplateSummary] = []

        for content_file in sorted((export_dir / "expanded").glob("*_content")):
            res_id = content_file.name.replace("_content", "")
            meta = resource_meta.get(res_id, {})
            template_id = uuid.uuid4().hex[:12]
            target_dir = TEMPLATE_DIR / template_id
            target_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(content_file, target_dir / (meta.get("name") or f"{res_id}.zip"))

            try:
                with zipfile.ZipFile(content_file, "r") as inner:
                    inner.extractall(target_dir / "expanded")
            except zipfile.BadZipFile:
                continue

            files = [p for p in (target_dir / "expanded").rglob("*") if p.is_file()]
            iflow = next((p for p in files if p.suffix.lower() == ".iflw"), None)
            text = iflow.read_text(encoding="utf-8", errors="ignore") if iflow else ""
            parsed = self._parse_iflow(text)
            groovy_files = [str(p.relative_to(target_dir / "expanded")).replace("\\","/") for p in files if p.suffix.lower()==".groovy"]
            mapping_files = [str(p.relative_to(target_dir / "expanded")).replace("\\","/") for p in files if p.suffix.lower() in {".mmap",".xsl",".xslt"}]
            desc = self._pick_attr(meta, "Description")

            script_signatures = []
            for g in [p for p in files if p.suffix.lower()==".groovy"][:5]:
                gt = g.read_text(encoding="utf-8", errors="ignore").lower()
                sig = []
                for token in ["setheader", "setproperty", "json", "xml", "filter", "processdata"]:
                    if token in gt:
                        sig.append(token)
                if sig:
                    script_signatures.append(f"{g.name}:{','.join(sig)}")

            summary = TemplateSummary(
                template_id=template_id,
                source_export=outer_zip.name,
                resource_id=res_id,
                resource_name=meta.get("name",""),
                display_name=meta.get("displayName", meta.get("uniqueId","") or meta.get("name","")),
                unique_id=meta.get("uniqueId",""),
                description=desc,
                operation=self._infer_operation(" ".join([meta.get("name",""), meta.get("uniqueId",""), desc, text])),
                sender_types=parsed["sender_types"],
                receiver_types=parsed["receiver_types"],
                methods=parsed["methods"],
                groovy_files=groovy_files,
                mapping_files=mapping_files,
                script_signatures=script_signatures,
                score_terms=sorted(set(
                    [meta.get("name",""), meta.get("uniqueId",""), desc] + parsed["sender_types"] + parsed["receiver_types"] + parsed["methods"] +
                    ["GROOVY" if groovy_files else "", "MAPPING" if mapping_files else ""]
                )),
                package_structure={
                    "root": str(target_dir),
                    "expanded": str(target_dir / "expanded"),
                    "iflow": str(iflow) if iflow else "",
                },
                raw_files=[str(p.relative_to(target_dir / "expanded")).replace("\\","/") for p in files],
            )
            summaries.append(summary)
        return summaries

    def _load_resource_metadata(self, expanded_dir: Path) -> Dict[str, dict]:
        cnt = expanded_dir / "resources.cnt"
        if not cnt.exists():
            return {}
        raw = cnt.read_text(encoding="utf-8", errors="ignore")
        try:
            js = json.loads(base64.b64decode(raw))
        except Exception:
            js = json.loads(raw)
        out = {}
        for item in js.get("resources", []):
            attrs = {}
            for key, meta in item.get("additionalAttributes", {}).items():
                vals = meta.get("attributeValues", [])
                attrs[key] = vals[0] if vals else ""
            out[item.get("id","")] = {
                "id": item.get("id",""),
                "name": item.get("name",""),
                "displayName": item.get("displayName",""),
                "uniqueId": item.get("uniqueId",""),
                **attrs,
            }
        return out

    def _pick_attr(self, meta: dict, key: str) -> str:
        return meta.get(key, "") if meta else ""

    def _infer_operation(self, text: str) -> str:
        upper = text.upper()
        for op in ["GET","POST","PUT","PATCH","DELETE","CREATE","UPDATE","UPSERT"]:
            if op in upper:
                return op
        return "UNKNOWN"

    def _parse_iflow(self, text: str) -> Dict[str, List[str]]:
        upper = text.upper()
        found = sorted({a for a in KNOWN_ADAPTERS if a in upper})
        sender = sorted({a for a in KNOWN_ADAPTERS if a in upper and re.search(rf"(SENDER|INBOUND).{{0,150}}{a}|{a}.{{0,150}}(SENDER|INBOUND)", upper, re.S)})
        receiver = sorted({a for a in KNOWN_ADAPTERS if a in upper and re.search(rf"(RECEIVER|OUTBOUND).{{0,150}}{a}|{a}.{{0,150}}(RECEIVER|OUTBOUND)", upper, re.S)})
        if not sender and found:
            sender = found[:1]
        if not receiver and len(found) > 1:
            receiver = found[1:2]
        elif not receiver and found:
            receiver = found[:1]
        methods = sorted({m for m in KNOWN_METHODS if re.search(rf"\b{m}\b", upper)})
        return {"sender_types": sender, "receiver_types": receiver, "methods": methods}
