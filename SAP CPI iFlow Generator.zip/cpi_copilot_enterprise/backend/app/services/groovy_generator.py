from __future__ import annotations
import re

def safe_name(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9_]+", "_", text).strip("_") or "script"

def indent(text: str, spaces: int) -> str:
    prefix = " " * spaces
    return "\n".join(prefix + line.rstrip() for line in text.strip("\n").splitlines())

def build_groovy(intent: dict) -> tuple[str, str]:
    req = intent.get("groovy_requirement", "payload passthrough").lower()
    name = safe_name(f"{intent.get('operation','GEN')}_{intent.get('sender_adapter') or 'FLOW'}_script") + ".groovy"
    if "timestamp" in req:
        logic = '''
message.setHeader("timestamp", new Date().toString())
return message
'''
    elif "namespace" in req:
        logic = '''
def body = message.getBody(String)
body = body.replace("oldNs", "newNs")
message.setBody(body)
return message
'''
    elif "json" in req and "xml" in req:
        logic = '''
def body = message.getBody(String)
// TODO: convert JSON payload to XML according to target schema
message.setBody(body)
return message
'''
    elif "filter" in req:
        logic = '''
def body = message.getBody(String)
// TODO: filter records according to business rules
message.setBody(body)
return message
'''
    else:
        logic = '''
def body = message.getBody(String)
// TODO: implement transformation as per prompt
message.setBody(body)
return message
'''
    code = f'''import com.sap.gateway.ip.core.customdev.util.Message
import java.util.Date

def Message processData(Message message) {{
{indent(logic, 4)}
}}
'''
    return name, code
