from __future__ import annotations
import json
from typing import List
from app.core.config import INDEX_PATH
from app.models import TemplateSummary

def load_index() -> List[TemplateSummary]:
    if not INDEX_PATH.exists():
        return []
    data = json.loads(INDEX_PATH.read_text(encoding="utf-8"))
    return [TemplateSummary(**item) for item in data]

def save_index(items: List[TemplateSummary]) -> None:
    INDEX_PATH.write_text(json.dumps([i.model_dump() for i in items], indent=2), encoding="utf-8")
