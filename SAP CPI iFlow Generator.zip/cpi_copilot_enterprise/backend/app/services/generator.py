from __future__ import annotations
import re
import shutil
import uuid
import zipfile
from pathlib import Path
from typing import List
from app.core.config import GENERATED_DIR
from app.models import TemplateSummary
from app.services.groovy_generator import build_groovy
from app.services.mapping_generator import build_mapping
from app.services.validator import validate_iflow_folder

def safe_name(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9_]+", "_", text).strip("_") or "iflow"

class Generator:
    def build(self, template: TemplateSummary, intent: dict, iflow_name: str, artifact_id: str | None) -> tuple[str, Path, List[str], List[str]]:
        generation_id = uuid.uuid4().hex[:12]
        target = GENERATED_DIR / generation_id
        shutil.copytree(Path(template.package_structure["expanded"]), target)

        created_files: List[str] = []
        iflow_files = list(target.rglob("*.iflw"))
        if iflow_files:
            iflow = iflow_files[0]
            new_iflow = iflow.with_name(f"{safe_name(iflow_name)}.iflw")
            iflow.rename(new_iflow)
            created_files.append(str(new_iflow.relative_to(target)).replace("\\","/"))

        for path in target.rglob("*"):
            if path.is_file() and path.suffix.lower() in {".iflw",".xml",".prop",".propdef",".mf",".project",".edmx",".wsdl",".xsd"}:
                txt = path.read_text(encoding="utf-8", errors="ignore")
                txt = self._patch_text(txt, template, intent, iflow_name, artifact_id)
                path.write_text(txt, encoding="utf-8")

        if intent.get("wants_groovy"):
            sname, scontent = build_groovy(intent)
            sdir = target / "src" / "main" / "resources" / "script"
            sdir.mkdir(parents=True, exist_ok=True)
            (sdir / sname).write_text(scontent, encoding="utf-8")
            created_files.append(str((sdir / sname).relative_to(target)).replace("\\","/"))

        if intent.get("wants_mapping"):
            mname, mcontent = build_mapping({"mapping_requirement": intent.get("mapping_requirement",""), "iflow_name": iflow_name})
            mdir = target / "src" / "main" / "resources" / "mapping"
            mdir.mkdir(parents=True, exist_ok=True)
            (mdir / mname).write_text(mcontent, encoding="utf-8")
            created_files.append(str((mdir / mname).relative_to(target)).replace("\\","/"))

        warnings = validate_iflow_folder(target)
        out_zip = GENERATED_DIR / f"{generation_id}.zip"
        with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as zf:
            for p in target.rglob("*"):
                if p.is_file():
                    zf.write(p, p.relative_to(target).as_posix())
        return generation_id, out_zip, warnings, created_files

    def _patch_text(self, text: str, template: TemplateSummary, intent: dict, iflow_name: str, artifact_id: str | None) -> str:
        out = text
        for old in [template.display_name, template.unique_id, template.resource_name.replace(".zip","")]:
            if old:
                out = out.replace(old, iflow_name)
        if artifact_id:
            out = re.sub(r"[A-Za-z0-9_]{5,}", lambda m: artifact_id if m.group(0) == safe_name(template.display_name or template.unique_id) else m.group(0), out, count=1)
        if intent.get("sender_name"):
            out = out.replace("Sender_1", intent["sender_name"])
        if intent.get("receiver_name"):
            out = out.replace("Receiver_1", intent["receiver_name"])
        if intent.get("path"):
            out = re.sub(r"/[A-Za-z0-9_\-/{}/:.]+", intent["path"], out, count=1)
        if intent.get("entity"):
            out = re.sub(r"A_[A-Za-z0-9_]+", intent["entity"], out, count=1)
        if intent.get("sender_adapter"):
            out = re.sub(r"\b(HTTPS|HTTP|ODATA|SOAP|SFTP|FTP|PROCESSDIRECT|IDOC|MAIL|XI)\b", intent["sender_adapter"], out, count=1)
        if intent.get("receiver_adapter"):
            out = re.sub(r"\b(HTTPS|HTTP|ODATA|SOAP|SFTP|FTP|PROCESSDIRECT|IDOC|MAIL|XI)\b", intent["receiver_adapter"], out, count=1)
        return out
