from __future__ import annotations
from collections import Counter
from math import sqrt
from typing import List, Tuple
from app.models import TemplateSummary

def find_best_templates(intent: dict, templates: List[TemplateSummary], top_k: int = 5) -> List[Tuple[TemplateSummary, float]]:
    q = _terms(intent)
    scored = []
    for t in templates:
        terms = _terms({
            "operation": t.operation,
            "sender": " ".join(t.sender_types),
            "receiver": " ".join(t.receiver_types),
            "methods": " ".join(t.methods),
            "description": t.description,
            "resource_name": t.resource_name,
            "display_name": t.display_name,
            "scripts": " ".join(t.script_signatures),
        })
        score = _cos(q, terms)
        if intent.get("operation") and t.operation == intent["operation"]:
            score += 0.5
        if intent.get("sender_adapter") and intent["sender_adapter"] in t.sender_types:
            score += 0.3
        if intent.get("receiver_adapter") and intent["receiver_adapter"] in t.receiver_types:
            score += 0.3
        if intent.get("wants_groovy") and t.groovy_files:
            score += 0.15
        if intent.get("wants_mapping") and t.mapping_files:
            score += 0.15
        scored.append((t, round(score, 4)))
    scored.sort(key=lambda x: x[1], reverse=True)
    return scored[:top_k]

def _terms(d: dict) -> list[str]:
    out = []
    for v in d.values():
        if isinstance(v, str):
            out.extend(v.upper().replace("/", " ").replace("-", " ").replace("_"," ").split())
    return out

def _cos(a: list[str], b: list[str]) -> float:
    A, B = Counter(a), Counter(b)
    common = set(A) & set(B)
    num = sum(A[t] * B[t] for t in common)
    if not num:
        return 0.0
    da = sqrt(sum(v*v for v in A.values()))
    db = sqrt(sum(v*v for v in B.values()))
    return num / (da * db)
