from __future__ import annotations
import re
from typing import Dict, Any

OPS = ["GET", "POST", "PUT", "PATCH", "DELETE", "CREATE", "UPDATE", "UPSERT"]
ADAPTERS = ["HTTPS", "HTTP", "ODATA", "SOAP", "SFTP", "FTP", "PROCESSDIRECT", "IDOC", "MAIL", "XI"]

def parse_prompt(prompt: str) -> Dict[str, Any]:
    text = prompt.strip()
    upper = text.upper()
    operation = next((op for op in OPS if re.search(rf"\b{op}\b", upper)), "GET")
    adapters = [a for a in ADAPTERS if a in upper]
    sender_adapter = adapters[0] if adapters else None
    receiver_adapter = adapters[1] if len(adapters) > 1 else None

    http_method = next((m for m in ["GET","POST","PUT","PATCH","DELETE"] if re.search(rf"\b{m}\b", upper)), None)
    wants_groovy = bool(re.search(r"\bgroovy\b|script|transform|header|payload|json|xml|namespace|filter", text, re.I))
    wants_mapping = bool(re.search(r"mapping|map|root|field|xsl|xslt|mmap", text, re.I))

    return {
        "operation": operation,
        "http_method": http_method or operation if operation in {"GET","POST","PUT","PATCH","DELETE"} else "",
        "sender_adapter": sender_adapter,
        "receiver_adapter": receiver_adapter,
        "sender_name": _extract_named_value(text, ["sender name", "sender", "sender channel"]) or "Sender_1",
        "receiver_name": _extract_named_value(text, ["receiver name", "receiver", "receiver channel"]) or "Receiver_1",
        "path": _extract_path(text) or "/generated/path",
        "entity": _extract_named_value(text, ["entity", "entity set", "odata entity"]) or "",
        "wants_groovy": wants_groovy,
        "wants_mapping": wants_mapping,
        "groovy_requirement": _extract_after_keyword(text, "groovy") or "payload passthrough",
        "mapping_requirement": _extract_after_keyword(text, "mapping") or "1:1 root mapping",
        "raw_prompt": text,
    }

def _extract_named_value(text: str, labels: list[str]) -> str | None:
    for label in labels:
        m = re.search(rf"{re.escape(label)}\s*(?:is|=|:)?\s*([\w\-/.]+)", text, re.I)
        if m:
            return m.group(1)
    return None

def _extract_after_keyword(text: str, keyword: str) -> str | None:
    m = re.search(rf"{keyword}\s*(?:to|for|:)?\s*(.+)", text, re.I)
    return m.group(1).strip()[:200] if m else None

def _extract_path(text: str) -> str | None:
    m = re.search(r"(\/[-\w\/{}/:.]+)", text)
    return m.group(1) if m else None
