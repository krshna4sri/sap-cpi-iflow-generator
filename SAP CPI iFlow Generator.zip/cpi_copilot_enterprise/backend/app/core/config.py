from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = ROOT / "data"
OUTER_EXPORT_DIR = DATA_DIR / "outer_exports"
TEMPLATE_DIR = DATA_DIR / "templates"
GENERATED_DIR = DATA_DIR / "generated"
INDEX_PATH = DATA_DIR / "template_index.json"

for path in [DATA_DIR, OUTER_EXPORT_DIR, TEMPLATE_DIR, GENERATED_DIR]:
    path.mkdir(parents=True, exist_ok=True)
