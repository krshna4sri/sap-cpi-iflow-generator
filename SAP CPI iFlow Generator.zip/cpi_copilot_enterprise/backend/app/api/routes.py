from __future__ import annotations
import shutil
from pathlib import Path
from typing import List
from fastapi import APIRouter, File, HTTPException, UploadFile

from app.core.config import OUTER_EXPORT_DIR, GENERATED_DIR
from app.models import GenerateRequest, GenerateResponse, DeployRequest, HealthResponse
from app.services.cpi_client import CPIClient
from app.services.export_parser import ExportParser
from app.services.generator import Generator
from app.services.index_store import load_index, save_index
from app.services.prompt_parser import parse_prompt
from app.services.retriever import find_best_templates

router = APIRouter()
parser = ExportParser()
generator = Generator()
cpi_client = CPIClient()

@router.get("/health", response_model=HealthResponse)
def health():
    return HealthResponse(status="ok", indexed_templates=len(load_index()))

@router.get("/templates")
def templates():
    return [t.model_dump() for t in load_index()]

@router.post("/train")
async def train(files: List[UploadFile] = File(...)):
    current = load_index()
    added = []
    for upload in files:
        if not upload.filename.lower().endswith(".zip"):
            continue
        temp = OUTER_EXPORT_DIR / f"_incoming_{upload.filename}"
        with temp.open("wb") as fh:
            shutil.copyfileobj(upload.file, fh)
        parsed = parser.ingest_export(temp)
        temp.unlink(missing_ok=True)
        current.extend(parsed)
        added.extend([p.model_dump() for p in parsed])
    save_index(current)
    return {"exports_uploaded": len(files), "templates_indexed": len(added)}

@router.post("/generate", response_model=GenerateResponse)
def generate(body: GenerateRequest):
    templates = load_index()
    if not templates:
        raise HTTPException(status_code=400, detail="No templates indexed. Use /train first.")
    intent = parse_prompt(body.prompt)
    if body.sender_name:
        intent["sender_name"] = body.sender_name
    if body.receiver_name:
        intent["receiver_name"] = body.receiver_name
    if body.preferred_sender:
        intent["sender_adapter"] = body.preferred_sender
    if body.preferred_receiver:
        intent["receiver_adapter"] = body.preferred_receiver
    intent["wants_groovy"] = body.auto_add_groovy or intent["wants_groovy"]
    intent["wants_mapping"] = body.inject_mapping or intent["wants_mapping"]

    matches = find_best_templates(intent, templates, top_k=5)
    if not matches:
        raise HTTPException(status_code=404, detail="No template match found.")
    best, _ = matches[0]
    generation_id, zip_path, warnings, created_files = generator.build(best, intent, body.iflow_name, body.artifact_id)

    return GenerateResponse(
        generation_id=generation_id,
        template_id=best.template_id,
        matched_template_name=best.display_name or best.resource_name,
        parsed_intent=intent,
        output_zip=str(zip_path),
        top_matches=[{
            "template_id": t.template_id,
            "display_name": t.display_name,
            "resource_name": t.resource_name,
            "score": score,
            "operation": t.operation,
            "sender_types": t.sender_types,
            "receiver_types": t.receiver_types,
        } for t, score in matches],
        warnings=warnings,
        created_files=created_files,
    )

@router.get("/export/{generation_id}")
def export(generation_id: str):
    zip_path = GENERATED_DIR / f"{generation_id}.zip"
    if not zip_path.exists():
        raise HTTPException(status_code=404, detail="Generation not found")
    return {"zip_path": str(zip_path)}

@router.post("/deploy")
def deploy(body: DeployRequest):
    zip_path = GENERATED_DIR / f"{body.generation_id}.zip"
    if not zip_path.exists():
        raise HTTPException(status_code=404, detail="Generation ZIP not found")
    auth = {"type": body.auth_type}
    if body.auth_type == "basic":
        auth.update({"username": body.username or "", "password": body.password or ""})
    else:
        auth.update({"client_id": body.client_id or "", "client_secret": body.client_secret or "", "token_url": body.token_url or ""})
    return cpi_client.deploy(body.tenant_url, body.package_id, zip_path, auth)
