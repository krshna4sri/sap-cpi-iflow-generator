# SAP CPI Copilot Enterprise

This package is a stronger end-to-end implementation for the 4 requested phases:

## What it handles
1. **Batch upload** of outer SAP CPI export ZIPs
2. **Training/indexing** of all inner iFlow packages found in those exports
3. **Generation** by retrieving the closest template and cloning/patching it
4. **Groovy writing** by creating a new Groovy script from prompt intent

## Key improvement over the earlier starter
It understands the **outer export format** that contains many `*_content` resources plus `resources.cnt`, then expands every inner package into a searchable template library.

## Run backend
```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Run frontend
```bash
cd frontend
streamlit run streamlit_app.py
```

## Reality check
This is the strongest buildable package I can produce here, but it is still not a guarantee that every generated ZIP will import cleanly into every CPI tenant. Final reliability depends on testing against your full export set and CPI import/deploy behavior.

## Suggested workflow
- Train on your exported packages
- Review indexed templates
- Generate against a few known prompts
- Test imports in a sandbox tenant
- Tighten patch rules based on observed structures
