# SAP CPI iFlow Intelligence Generator

AI-powered iFlow authoring, template management, and auto-deployment for SAP Cloud Platform Integration.

Built on top of the original clone-based approach — extended with Claude AI, streaming UI, and CPI REST deployment.

---

## What This Does

| Feature | Description |
|---|---|
| **Template Library** | Upload your 200+ iFlow ZIPs — stored as reusable templates |
| **AI Generation** | Claude AI reads your template XML + user prompt → modifies and personalises the iFlow |
| **Streaming UI** | Watch the generation happen in real time, section by section |
| **Export ZIP** | Download a valid, importable SAP CPI iFlow ZIP |
| **Auto-Deploy** | POST the iFlow directly to your CPI tenant via REST API |
| **Groovy Studio** | Generate Groovy transformation scripts with AI |

---

## Quick Start

### Prerequisites
- Python 3.10+
- An Anthropic API key → https://console.anthropic.com
- (Optional) Docker for one-command run

### Option 1 — Run directly

```bash
# 1. Set your API key
export ANTHROPIC_API_KEY=sk-ant-...

# 2. Run setup + start
chmod +x start.sh
./start.sh

# 3. Open frontend/index.html in your browser
```

### Option 2 — Docker

```bash
export ANTHROPIC_API_KEY=sk-ant-...
docker-compose up --build
# Frontend: http://localhost:3000
# Backend:  http://localhost:8000
```

---

## How to Use

### Step 1 — Upload Templates
1. Click **Template Library** tab
2. Upload your iFlow ZIP files (drag & drop supported)
3. Select the operation type (GET / CREATE / UPDATE / DELETE) for each

### Step 2 — Generate an iFlow
1. Click **Generate iFlow** tab
2. Fill in the 5-step wizard:
   - **Prompt**: Describe the iFlow in plain English
   - **Adapter**: Sender/receiver adapter types, HTTP method, paths
   - **Groovy**: Optional transformation script
   - **Mapping**: Message mapping level
   - **Generate**: Review config and click Generate
3. Watch Claude AI stream the generation in real time
4. Click **Download iFlow ZIP** to get the exportable file

### Step 3 — Deploy (Optional)
1. Click **Deploy to CPI** or the Deploy button after generation
2. Enter your CPI tenant URL, credentials, and package ID
3. Click Deploy — the iFlow is created and started automatically

---

## Project Structure

```
sap-cpi-generator/
├── backend/
│   ├── main.py              ← FastAPI backend (all logic)
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/
│   └── index.html           ← Complete single-file React-like UI
├── template_library/        ← Uploaded iFlow ZIPs stored here
├── docker-compose.yml
├── start.sh
└── README.md
```

---

## API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | /api/health | Health check + template count |
| POST | /api/templates/upload | Upload an iFlow ZIP as template |
| GET | /api/templates | List all templates |
| DELETE | /api/templates/{id} | Delete a template |
| POST | /api/generate/stream | Stream iFlow generation (SSE) |
| POST | /api/generate/export | Download generated iFlow as ZIP |
| POST | /api/deploy | Deploy to SAP CPI via REST API |
| POST | /api/groovy/generate | Generate a Groovy script |

---

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `ANTHROPIC_API_KEY` | ✓ Yes | Your Anthropic API key |
| `TEMPLATE_DIR` | No | Path to template storage (default: ./template_library) |

---

## Extending the System

### Adding more iFlow variants
Upload more ZIPs in the Template Library. The system auto-indexes them by operation type.

### Adding ChromaDB vector search (Phase 2)
Install `chromadb` and `openai` — the backend is structured to plug in vector search on the `find_best_template()` function for semantic similarity matching across 200+ templates.

### Adding OAuth 2.0 for CPI deployment
Update the `deploy_to_cpi()` route to use `httpx` with OAuth2 client credentials flow. Swap the `auth=` parameter with a Bearer token header.

---

## Credits

Built on top of the original SAP CPI iFlow Generator by krshna4sri
https://github.com/krshna4sri/sap-cpi-iflow-generator

Extended with:
- FastAPI backend with streaming SSE
- Claude AI (Anthropic) for intelligent XML modification
- Multi-template library management
- CPI REST API auto-deployment
