#!/bin/bash
# ─── SAP CPI iFlow Generator — Quick Start ───────────────────────────────────

set -e

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║   SAP CPI iFlow Intelligence Generator — Setup       ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# Check for API key
if [ -z "$ANTHROPIC_API_KEY" ]; then
  echo "⚠  ANTHROPIC_API_KEY is not set."
  read -p "   Enter your Anthropic API key: " ANTHROPIC_API_KEY
  export ANTHROPIC_API_KEY
fi

# Check Python
if ! command -v python3 &> /dev/null; then
  echo "✕ Python 3 is required. Install from https://python.org"
  exit 1
fi

echo "✓ Python found: $(python3 --version)"

# Install backend deps
echo ""
echo "▶ Installing backend dependencies..."
cd backend
pip install -r requirements.txt --quiet
cd ..

# Create template library dir
mkdir -p template_library

echo ""
echo "✓ Setup complete!"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "▶ Starting backend on http://localhost:8000 ..."
echo "▶ Open frontend/index.html in your browser"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

cd backend
python3 -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
