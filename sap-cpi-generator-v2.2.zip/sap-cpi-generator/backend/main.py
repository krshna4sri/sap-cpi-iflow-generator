"""
SAP CPI iFlow Intelligence Generator — FastAPI Backend v2.1
Includes:
  - BUILT-IN skeleton iFlow templates (GET, CREATE, UPDATE, DELETE)
    baked directly into code — works with zero file uploads
  - OBJECT_PRESETS ported from original Automatic Iflow.py
  - Uploaded user ZIPs extend the built-in library
  - Claude AI streaming generation + XML modification
  - CPI auto-deploy via REST API
"""

import asyncio
import io
import json
import os
import re
import zipfile
from pathlib import Path
from typing import AsyncGenerator, Dict, List, Optional, Tuple

import anthropic
import httpx
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

app = FastAPI(title="SAP CPI iFlow Generator", version="2.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
TEMPLATE_DIR = Path(os.getenv("TEMPLATE_DIR", "./template_library"))
TEMPLATE_DIR.mkdir(parents=True, exist_ok=True)

client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

TEXT_FILE_SUFFIXES = {
    ".iflw", ".groovy", ".prop", ".propdef", ".mf", ".edmx",
    ".xsd", ".wsdl", ".mmap", ".project", ".xml"
}

# =============================================================================
# BUILT-IN SKELETON TEMPLATES — baked directly into this file
# These are minimal but valid SAP CPI BPMN iFlow XMLs.
# No ZIP upload required. System works immediately out of the box.
# When you upload real iFlow ZIPs they extend (not replace) these skeletons.
# =============================================================================

SKELETON_GET_IFLW = '''<?xml version="1.0" encoding="UTF-8"?>
<bpmn2:definitions
  xmlns:bpmn2="http://www.omg.org/spec/BPMN/20100524/MODEL"
  xmlns:ifl="http:///com.sap.ifl.model/Ifl.xsd"
  id="Definitions_1" targetNamespace="http://sap.com/xi/SAP_XI_TradeSpecificNamespace">

  <bpmn2:collaboration id="Collaboration_1">
    <bpmn2:participant id="Sender"   name="Sender_HTTPS"           processRef="SenderProcess"/>
    <bpmn2:participant id="Receiver" name="Receiver_OData"          processRef="ReceiverProcess"/>
    <bpmn2:participant id="IntProc"  name="IFLOW_DISPLAY_NAME"      processRef="IntegrationProcess"/>
    <bpmn2:messageFlow id="MF_In"  sourceRef="Sender"     targetRef="StartEvent_1"/>
    <bpmn2:messageFlow id="MF_Out" sourceRef="EndEvent_1" targetRef="Receiver"/>
  </bpmn2:collaboration>

  <bpmn2:process id="SenderProcess" name="Sender_HTTPS" isExecutable="false">
    <bpmn2:extensionElements>
      <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>ConnectorInterface</ifl:value></ifl:property>
    </bpmn2:extensionElements>
  </bpmn2:process>

  <bpmn2:process id="ReceiverProcess" name="Receiver_OData" isExecutable="false">
    <bpmn2:extensionElements>
      <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>ConnectorInterface</ifl:value></ifl:property>
    </bpmn2:extensionElements>
  </bpmn2:process>

  <bpmn2:process id="IntegrationProcess" name="IFLOW_DISPLAY_NAME" isExecutable="true">
    <bpmn2:extensionElements>
      <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>IFlow</ifl:value></ifl:property>
    </bpmn2:extensionElements>

    <bpmn2:startEvent id="StartEvent_1" name="Start">
      <bpmn2:extensionElements>
        <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>StartEvent</ifl:value></ifl:property>
        <ifl:property><ifl:key>address</ifl:key><ifl:value>SENDER_PATH</ifl:value></ifl:property>
        <ifl:property><ifl:key>httpMethod</ifl:key><ifl:value>GET</ifl:value></ifl:property>
        <ifl:property><ifl:key>enableBasicAuthentication</ifl:key><ifl:value>true</ifl:value></ifl:property>
      </bpmn2:extensionElements>
      <bpmn2:outgoing>Seq_Start_CM</bpmn2:outgoing>
    </bpmn2:startEvent>

    <bpmn2:serviceTask id="ContentModifier_1" name="Set_Headers">
      <bpmn2:extensionElements>
        <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>ContentModifier</ifl:value></ifl:property>
        <ifl:property><ifl:key>messageHeaderTable</ifl:key><ifl:value>Accept:application/json</ifl:value></ifl:property>
      </bpmn2:extensionElements>
      <bpmn2:incoming>Seq_Start_CM</bpmn2:incoming>
      <bpmn2:outgoing>Seq_CM_Recv</bpmn2:outgoing>
    </bpmn2:serviceTask>

    <bpmn2:serviceTask id="ODataCall_1" name="GET_ENTITY_NAME">
      <bpmn2:extensionElements>
        <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>OData</ifl:value></ifl:property>
        <ifl:property><ifl:key>address</ifl:key><ifl:value>ODATA_ADDRESS</ifl:value></ifl:property>
        <ifl:property><ifl:key>entitySetName</ifl:key><ifl:value>ENTITY_NAME</ifl:value></ifl:property>
        <ifl:property><ifl:key>operation</ifl:key><ifl:value>GET</ifl:value></ifl:property>
        <ifl:property><ifl:key>authenticationMethod</ifl:key><ifl:value>BasicAuthentication</ifl:value></ifl:property>
        <ifl:property><ifl:key>credentialName</ifl:key><ifl:value>S4HANA_CRED</ifl:value></ifl:property>
      </bpmn2:extensionElements>
      <bpmn2:incoming>Seq_CM_Recv</bpmn2:incoming>
      <bpmn2:outgoing>Seq_Recv_End</bpmn2:outgoing>
    </bpmn2:serviceTask>

    <bpmn2:endEvent id="EndEvent_1" name="End">
      <bpmn2:extensionElements>
        <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>EndEvent</ifl:value></ifl:property>
      </bpmn2:extensionElements>
      <bpmn2:incoming>Seq_Recv_End</bpmn2:incoming>
    </bpmn2:endEvent>

    <bpmn2:sequenceFlow id="Seq_Start_CM"  sourceRef="StartEvent_1"    targetRef="ContentModifier_1"/>
    <bpmn2:sequenceFlow id="Seq_CM_Recv"   sourceRef="ContentModifier_1" targetRef="ODataCall_1"/>
    <bpmn2:sequenceFlow id="Seq_Recv_End"  sourceRef="ODataCall_1"     targetRef="EndEvent_1"/>
  </bpmn2:process>
</bpmn2:definitions>'''

SKELETON_CREATE_IFLW = '''<?xml version="1.0" encoding="UTF-8"?>
<bpmn2:definitions
  xmlns:bpmn2="http://www.omg.org/spec/BPMN/20100524/MODEL"
  xmlns:ifl="http:///com.sap.ifl.model/Ifl.xsd"
  id="Definitions_1" targetNamespace="http://sap.com/xi/SAP_XI_TradeSpecificNamespace">

  <bpmn2:collaboration id="Collaboration_1">
    <bpmn2:participant id="Sender"  name="Sender_HTTPS"        processRef="SenderProcess"/>
    <bpmn2:participant id="Receiver" name="Receiver_OData"     processRef="ReceiverProcess"/>
    <bpmn2:participant id="IntProc" name="IFLOW_DISPLAY_NAME"  processRef="IntegrationProcess"/>
    <bpmn2:messageFlow id="MF_In"  sourceRef="Sender"     targetRef="StartEvent_1"/>
    <bpmn2:messageFlow id="MF_Out" sourceRef="EndEvent_1" targetRef="Receiver"/>
  </bpmn2:collaboration>

  <bpmn2:process id="SenderProcess"   name="Sender_HTTPS"   isExecutable="false"/>
  <bpmn2:process id="ReceiverProcess" name="Receiver_OData"  isExecutable="false"/>

  <bpmn2:process id="IntegrationProcess" name="IFLOW_DISPLAY_NAME" isExecutable="true">
    <bpmn2:extensionElements>
      <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>IFlow</ifl:value></ifl:property>
    </bpmn2:extensionElements>

    <bpmn2:startEvent id="StartEvent_1" name="Start">
      <bpmn2:extensionElements>
        <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>StartEvent</ifl:value></ifl:property>
        <ifl:property><ifl:key>address</ifl:key><ifl:value>SENDER_PATH</ifl:value></ifl:property>
        <ifl:property><ifl:key>httpMethod</ifl:key><ifl:value>POST</ifl:value></ifl:property>
        <ifl:property><ifl:key>enableBasicAuthentication</ifl:key><ifl:value>true</ifl:value></ifl:property>
      </bpmn2:extensionElements>
      <bpmn2:outgoing>Seq_Start_Script</bpmn2:outgoing>
    </bpmn2:startEvent>

    <bpmn2:scriptTask id="GroovyScript_1" name="Transform_Payload" scriptFormat="groovy">
      <bpmn2:extensionElements>
        <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>ScriptTask</ifl:value></ifl:property>
        <ifl:property><ifl:key>scriptFile</ifl:key><ifl:value>script/IFLOW_DISPLAY_NAME_transform.groovy</ifl:value></ifl:property>
      </bpmn2:extensionElements>
      <bpmn2:incoming>Seq_Start_Script</bpmn2:incoming>
      <bpmn2:outgoing>Seq_Script_Recv</bpmn2:outgoing>
    </bpmn2:scriptTask>

    <bpmn2:serviceTask id="ODataCall_1" name="CREATE_ENTITY_NAME">
      <bpmn2:extensionElements>
        <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>OData</ifl:value></ifl:property>
        <ifl:property><ifl:key>address</ifl:key><ifl:value>ODATA_ADDRESS</ifl:value></ifl:property>
        <ifl:property><ifl:key>entitySetName</ifl:key><ifl:value>ENTITY_NAME</ifl:value></ifl:property>
        <ifl:property><ifl:key>operation</ifl:key><ifl:value>CREATE</ifl:value></ifl:property>
        <ifl:property><ifl:key>authenticationMethod</ifl:key><ifl:value>BasicAuthentication</ifl:value></ifl:property>
        <ifl:property><ifl:key>credentialName</ifl:key><ifl:value>S4HANA_CRED</ifl:value></ifl:property>
      </bpmn2:extensionElements>
      <bpmn2:incoming>Seq_Script_Recv</bpmn2:incoming>
      <bpmn2:outgoing>Seq_Recv_End</bpmn2:outgoing>
    </bpmn2:serviceTask>

    <bpmn2:endEvent id="EndEvent_1" name="End">
      <bpmn2:extensionElements>
        <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>EndEvent</ifl:value></ifl:property>
      </bpmn2:extensionElements>
      <bpmn2:incoming>Seq_Recv_End</bpmn2:incoming>
    </bpmn2:endEvent>

    <bpmn2:sequenceFlow id="Seq_Start_Script" sourceRef="StartEvent_1"   targetRef="GroovyScript_1"/>
    <bpmn2:sequenceFlow id="Seq_Script_Recv"  sourceRef="GroovyScript_1" targetRef="ODataCall_1"/>
    <bpmn2:sequenceFlow id="Seq_Recv_End"     sourceRef="ODataCall_1"    targetRef="EndEvent_1"/>
  </bpmn2:process>
</bpmn2:definitions>'''

SKELETON_UPDATE_IFLW = SKELETON_CREATE_IFLW.replace(
    "<ifl:value>POST</ifl:value>", "<ifl:value>PUT</ifl:value>"
).replace(
    "<ifl:value>CREATE</ifl:value>", "<ifl:value>UPDATE</ifl:value>"
).replace("CREATE_ENTITY_NAME", "UPDATE_ENTITY_NAME")

SKELETON_DELETE_IFLW = '''<?xml version="1.0" encoding="UTF-8"?>
<bpmn2:definitions
  xmlns:bpmn2="http://www.omg.org/spec/BPMN/20100524/MODEL"
  xmlns:ifl="http:///com.sap.ifl.model/Ifl.xsd"
  id="Definitions_1" targetNamespace="http://sap.com/xi/SAP_XI_TradeSpecificNamespace">

  <bpmn2:collaboration id="Collaboration_1">
    <bpmn2:participant id="Sender"  name="Sender_HTTPS"        processRef="SenderProcess"/>
    <bpmn2:participant id="Receiver" name="Receiver_OData"     processRef="ReceiverProcess"/>
    <bpmn2:participant id="IntProc" name="IFLOW_DISPLAY_NAME"  processRef="IntegrationProcess"/>
    <bpmn2:messageFlow id="MF_In"  sourceRef="Sender"     targetRef="StartEvent_1"/>
    <bpmn2:messageFlow id="MF_Out" sourceRef="EndEvent_1" targetRef="Receiver"/>
  </bpmn2:collaboration>

  <bpmn2:process id="SenderProcess"   name="Sender_HTTPS"   isExecutable="false"/>
  <bpmn2:process id="ReceiverProcess" name="Receiver_OData"  isExecutable="false"/>

  <bpmn2:process id="IntegrationProcess" name="IFLOW_DISPLAY_NAME" isExecutable="true">
    <bpmn2:extensionElements>
      <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>IFlow</ifl:value></ifl:property>
    </bpmn2:extensionElements>

    <bpmn2:startEvent id="StartEvent_1" name="Start">
      <bpmn2:extensionElements>
        <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>StartEvent</ifl:value></ifl:property>
        <ifl:property><ifl:key>address</ifl:key><ifl:value>SENDER_PATH</ifl:value></ifl:property>
        <ifl:property><ifl:key>httpMethod</ifl:key><ifl:value>DELETE</ifl:value></ifl:property>
        <ifl:property><ifl:key>enableBasicAuthentication</ifl:key><ifl:value>true</ifl:value></ifl:property>
      </bpmn2:extensionElements>
      <bpmn2:outgoing>Seq_Start_Recv</bpmn2:outgoing>
    </bpmn2:startEvent>

    <bpmn2:serviceTask id="ODataCall_1" name="DELETE_ENTITY_NAME">
      <bpmn2:extensionElements>
        <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>OData</ifl:value></ifl:property>
        <ifl:property><ifl:key>address</ifl:key><ifl:value>ODATA_ADDRESS</ifl:value></ifl:property>
        <ifl:property><ifl:key>entitySetName</ifl:key><ifl:value>ENTITY_NAME</ifl:value></ifl:property>
        <ifl:property><ifl:key>operation</ifl:key><ifl:value>DELETE</ifl:value></ifl:property>
        <ifl:property><ifl:key>authenticationMethod</ifl:key><ifl:value>BasicAuthentication</ifl:value></ifl:property>
        <ifl:property><ifl:key>credentialName</ifl:key><ifl:value>S4HANA_CRED</ifl:value></ifl:property>
      </bpmn2:extensionElements>
      <bpmn2:incoming>Seq_Start_Recv</bpmn2:incoming>
      <bpmn2:outgoing>Seq_Recv_End</bpmn2:outgoing>
    </bpmn2:serviceTask>

    <bpmn2:endEvent id="EndEvent_1" name="End">
      <bpmn2:extensionElements>
        <ifl:property><ifl:key>ComponentType</ifl:key><ifl:value>EndEvent</ifl:value></ifl:property>
      </bpmn2:extensionElements>
      <bpmn2:incoming>Seq_Recv_End</bpmn2:incoming>
    </bpmn2:endEvent>

    <bpmn2:sequenceFlow id="Seq_Start_Recv" sourceRef="StartEvent_1" targetRef="ODataCall_1"/>
    <bpmn2:sequenceFlow id="Seq_Recv_End"   sourceRef="ODataCall_1"  targetRef="EndEvent_1"/>
  </bpmn2:process>
</bpmn2:definitions>'''

DEFAULT_GROOVY = '''import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

// SAP CPI Groovy Transformation Script
// Auto-generated by CPI iFlow Intelligence Generator

def Message processData(Message message) {
    try {
        // Read payload and headers
        def body = message.getBody(String.class)
        def headers = message.getHeaders()

        // Log input for monitoring
        def messageLog = messageLogFactory.getMessageLog(message)
        if (messageLog != null) {
            messageLog.addAttachmentAsString("Input_Payload", body, "text/plain")
        }

        // ── TODO: Add transformation logic here ──
        // Example JSON transform:
        // def json = new groovy.json.JsonSlurper().parseText(body)
        // def output = groovy.json.JsonOutput.toJson([result: json])
        // message.setBody(output)

        // Set response headers
        message.setHeader("Content-Type", "application/json")
        message.setHeader("X-Source", "SAP-CPI")

    } catch (Exception e) {
        throw new Exception("Groovy transformation failed: " + e.getMessage(), e)
    }

    return message
}'''

MANIFEST_TEMPLATE = """Manifest-Version: 1.0
Bundle-ManifestVersion: 2
Bundle-Name: IFLOW_DISPLAY_NAME
Bundle-SymbolicName: ARTIFACT_ID
Bundle-Version: 1.0.0
SAP-BundleType: IFlow
"""

# =============================================================================
# BUILT-IN TEMPLATE REGISTRY — immediately available, no upload needed
# =============================================================================

BUILTIN_TEMPLATES: Dict[str, Dict] = {
    "builtin_get": {
        "id": "builtin_get",
        "name": "Skeleton GET iFlow",
        "operation": "GET",
        "source": "builtin",
        "description": "Minimal HTTPS→OData GET skeleton. Start → ContentModifier → OData GET → End",
        "sender_adapter": "HTTPS",
        "receiver_adapter": "OData",
        "http_method": "GET",
        "sender_path": "/api/v1/get",
        "entity_name": "ENTITY_NAME",
        "odata_address": "https://your-s4hana.example.com/sap/opu/odata/sap/API_SRV",
        "iflow_xml": SKELETON_GET_IFLW,
        "groovy": None,
        "has_mapping": False,
        "iflow_files": ["src/main/resources/scenarioflows/integrationflow/skeleton_get.iflw"],
        "groovy_files": [],
        "file_size": len(SKELETON_GET_IFLW),
    },
    "builtin_create": {
        "id": "builtin_create",
        "name": "Skeleton CREATE iFlow",
        "operation": "CREATE",
        "source": "builtin",
        "description": "Minimal HTTPS→OData POST skeleton with Groovy step. Start → Groovy → OData CREATE → End",
        "sender_adapter": "HTTPS",
        "receiver_adapter": "OData",
        "http_method": "POST",
        "sender_path": "/api/v1/create",
        "entity_name": "ENTITY_NAME",
        "odata_address": "https://your-s4hana.example.com/sap/opu/odata/sap/API_SRV",
        "iflow_xml": SKELETON_CREATE_IFLW,
        "groovy": DEFAULT_GROOVY,
        "has_mapping": False,
        "iflow_files": ["src/main/resources/scenarioflows/integrationflow/skeleton_create.iflw"],
        "groovy_files": ["src/main/resources/script/skeleton_create_transform.groovy"],
        "file_size": len(SKELETON_CREATE_IFLW),
    },
    "builtin_update": {
        "id": "builtin_update",
        "name": "Skeleton UPDATE iFlow",
        "operation": "UPDATE",
        "source": "builtin",
        "description": "Minimal HTTPS→OData PUT skeleton with Groovy step. Start → Groovy → OData UPDATE → End",
        "sender_adapter": "HTTPS",
        "receiver_adapter": "OData",
        "http_method": "PUT",
        "sender_path": "/api/v1/update",
        "entity_name": "ENTITY_NAME",
        "odata_address": "https://your-s4hana.example.com/sap/opu/odata/sap/API_SRV",
        "iflow_xml": SKELETON_UPDATE_IFLW,
        "groovy": DEFAULT_GROOVY,
        "has_mapping": False,
        "iflow_files": ["src/main/resources/scenarioflows/integrationflow/skeleton_update.iflw"],
        "groovy_files": ["src/main/resources/script/skeleton_update_transform.groovy"],
        "file_size": len(SKELETON_UPDATE_IFLW),
    },
    "builtin_delete": {
        "id": "builtin_delete",
        "name": "Skeleton DELETE iFlow",
        "operation": "DELETE",
        "source": "builtin",
        "description": "Minimal HTTPS→OData DELETE skeleton. Start → OData DELETE → End",
        "sender_adapter": "HTTPS",
        "receiver_adapter": "OData",
        "http_method": "DELETE",
        "sender_path": "/api/v1/delete",
        "entity_name": "ENTITY_NAME",
        "odata_address": "https://your-s4hana.example.com/sap/opu/odata/sap/API_SRV",
        "iflow_xml": SKELETON_DELETE_IFLW,
        "groovy": None,
        "has_mapping": False,
        "iflow_files": ["src/main/resources/scenarioflows/integrationflow/skeleton_delete.iflw"],
        "groovy_files": [],
        "file_size": len(SKELETON_DELETE_IFLW),
    },
}

# =============================================================================
# OBJECT PRESETS — ported + extended from original Automatic Iflow.py
# These pre-fill form values when user selects a known SAP object type
# =============================================================================

OBJECT_PRESETS: Dict[str, Dict[str, Dict]] = {
    "GET": {
        "Journal Entry": {
            "description": "GET Journal Entry items from SAP S/4HANA",
            "sender_path": "/JournalEntry/Get",
            "entity_name": "A_JournalEntryItemBasic",
            "odata_address": "https://my-tenant-api.s4hana.cloud.sap/sap/opu/odata/sap/API_JOURNALENTRYITEMBASIC_SRV",
        },
        "Purchase Order": {
            "description": "GET Purchase Orders from SAP S/4HANA",
            "sender_path": "/PurchaseOrder/Get",
            "entity_name": "A_PurchaseOrder",
            "odata_address": "https://my-tenant-api.s4hana.cloud.sap/sap/opu/odata/sap/API_PURCHASEORDER_PROCESS_SRV",
        },
        "Sales Order": {
            "description": "GET Sales Orders from SAP S/4HANA",
            "sender_path": "/SalesOrder/Get",
            "entity_name": "A_SalesOrder",
            "odata_address": "https://my-tenant-api.s4hana.cloud.sap/sap/opu/odata/sap/API_SALES_ORDER_SRV",
        },
        "Company Code": {
            "description": "GET Company Code master data",
            "sender_path": "/CompanyCode/Get",
            "entity_name": "A_CompanyCode",
            "odata_address": "https://my-tenant-api.s4hana.cloud.sap/sap/opu/odata/sap/API_COMPANYCODE_SRV",
        },
        "Material / Product": {
            "description": "GET Material/Product master data",
            "sender_path": "/Material/Get",
            "entity_name": "A_Product",
            "odata_address": "https://my-tenant-api.s4hana.cloud.sap/sap/opu/odata/sap/API_PRODUCT_SRV",
        },
        "Business Partner": {
            "description": "GET Business Partner from SAP S/4HANA",
            "sender_path": "/BusinessPartner/Get",
            "entity_name": "A_BusinessPartner",
            "odata_address": "https://my-tenant-api.s4hana.cloud.sap/sap/opu/odata/sap/API_BUSINESS_PARTNER",
        },
        "Custom": {
            "description": "GET custom entity",
            "sender_path": "/custom/get",
            "entity_name": "A_CustomEntity",
            "odata_address": "",
        },
    },
    "CREATE": {
        "Purchase Order": {
            "description": "Create Purchase Order in SAP S/4HANA",
            "sender_path": "/PurchaseOrder/Create",
            "entity_name": "A_PurchaseOrder",
            "odata_address": "https://my-tenant-api.s4hana.cloud.sap/sap/opu/odata/sap/API_PURCHASEORDER_PROCESS_SRV",
        },
        "Sales Order": {
            "description": "Create Sales Order in SAP S/4HANA",
            "sender_path": "/SalesOrder/Create",
            "entity_name": "A_SalesOrder",
            "odata_address": "",
        },
        "Project Elements": {
            "description": "Create Project Elements (ported from original)",
            "sender_path": "/ProjectElements/Create",
            "entity_name": "A_WorkPackage",
            "odata_address": "",
        },
        "Custom": {
            "description": "Create custom entity",
            "sender_path": "/custom/create",
            "entity_name": "A_CustomEntity",
            "odata_address": "",
        },
    },
    "UPDATE": {
        "Purchase Order": {
            "description": "Update Purchase Order in SAP S/4HANA",
            "sender_path": "/PurchaseOrder/Update",
            "entity_name": "A_PurchaseOrder",
            "odata_address": "",
        },
        "Project Elements": {
            "description": "Update Project Elements (ported from original)",
            "sender_path": "/ProjectElements/Update",
            "entity_name": "A_WorkPackage",
            "odata_address": "",
        },
        "Custom": {
            "description": "Update custom entity",
            "sender_path": "/custom/update",
            "entity_name": "A_CustomEntity",
            "odata_address": "",
        },
    },
    "DELETE": {
        "Purchase Order": {
            "description": "Delete Purchase Order (ported from original)",
            "sender_path": "/PurchaseOrder/Delete",
            "entity_name": "A_PurchaseOrder",
            "odata_address": "",
        },
        "Custom": {
            "description": "Delete custom entity",
            "sender_path": "/custom/delete",
            "entity_name": "A_CustomEntity",
            "odata_address": "",
        },
    },
}


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def safe_slug(text: str) -> str:
    v = re.sub(r"[^A-Za-z0-9]+", "_", text.strip())
    return re.sub(r"_+", "_", v).strip("_") or "iflow"


def get_template_meta_path(tid: str) -> Path:
    return TEMPLATE_DIR / f"{tid}.meta.json"


def get_template_zip_path(tid: str) -> Path:
    return TEMPLATE_DIR / f"{tid}.zip"


def list_uploaded_templates() -> List[Dict]:
    result = []
    for p in TEMPLATE_DIR.glob("*.meta.json"):
        try:
            m = json.loads(p.read_text())
            m["source"] = "uploaded"
            result.append(m)
        except Exception:
            pass
    return result


def list_all_templates() -> List[Dict]:
    return list(BUILTIN_TEMPLATES.values()) + list_uploaded_templates()


def find_best_template(operation: str, template_id: Optional[str] = None) -> Optional[Dict]:
    op = operation.upper()
    # 1. Exact ID match
    if template_id:
        if template_id in BUILTIN_TEMPLATES:
            return BUILTIN_TEMPLATES[template_id]
        p = get_template_meta_path(template_id)
        if p.exists():
            return json.loads(p.read_text())
    # 2. First uploaded template for this operation
    for m in list_uploaded_templates():
        if m.get("operation", "").upper() == op:
            return m
    # 3. Built-in skeleton fallback
    return BUILTIN_TEMPLATES.get(f"builtin_{op.lower()}")


def parse_zip_metadata(zip_bytes: bytes, operation: str, name: str) -> Dict:
    iflow_files, groovy_files, has_mapping = [], [], False
    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
            for n in zf.namelist():
                if n.endswith(".iflw"):    iflow_files.append(n)
                elif n.endswith(".groovy"): groovy_files.append(n)
                elif n.endswith(".mmap"):   has_mapping = True
    except Exception:
        pass
    return {
        "id": safe_slug(name), "name": name, "operation": operation.upper(),
        "source": "uploaded", "file_size": len(zip_bytes),
        "iflow_files": iflow_files, "groovy_files": groovy_files, "has_mapping": has_mapping,
    }


def get_template_xml(template: Dict) -> str:
    if template.get("source") == "builtin":
        return template.get("iflow_xml", "")
    z = get_template_zip_path(template["id"])
    if z.exists():
        try:
            with zipfile.ZipFile(z) as zf:
                for n in zf.namelist():
                    if n.endswith(".iflw"):
                        return zf.read(n).decode("utf-8", errors="replace")
        except Exception:
            pass
    return ""


def build_iflow_zip(iflow_name: str, artifact_id: str, iflow_xml: str, groovy_code: Optional[str]) -> bytes:
    slug = safe_slug(iflow_name)
    manifest = MANIFEST_TEMPLATE.replace("IFLOW_DISPLAY_NAME", iflow_name).replace("ARTIFACT_ID", artifact_id)
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("META-INF/MANIFEST.MF", manifest)
        zf.writestr(f"src/main/resources/scenarioflows/integrationflow/{slug}.iflw", iflow_xml)
        if groovy_code:
            zf.writestr(f"src/main/resources/script/{slug}_transform.groovy", groovy_code)
        zf.writestr(".project", f"""<?xml version="1.0" encoding="UTF-8"?>
<projectDescription>
  <name>{artifact_id}</name>
  <comment>{iflow_name}</comment>
  <natures><nature>com.sap.it.spc.webui.nature.IntegrationFlow</nature></natures>
</projectDescription>""")
    return out.getvalue()


def apply_replacements_to_zip(zip_bytes: bytes, replacements: List[Tuple[str, str]], new_name: str) -> bytes:
    out = io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(zip_bytes), "r") as zin:
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                data = zin.read(item.filename)
                fname = item.filename
                sfx = Path(fname).suffix.lower()
                if sfx == ".iflw":
                    slug = safe_slug(new_name)
                    parent = str(Path(fname).parent)
                    fname = f"{parent}/{slug}.iflw" if parent != "." else f"{slug}.iflw"
                if sfx in TEXT_FILE_SUFFIXES:
                    try:
                        text = data.decode("utf-8")
                        for old, new in replacements:
                            if old and old != new:
                                text = text.replace(old, new)
                        data = text.encode("utf-8")
                    except Exception:
                        pass
                zout.writestr(fname, data)
    return out.getvalue()


# =============================================================================
# PYDANTIC MODELS
# =============================================================================

class GenerateRequest(BaseModel):
    prompt: str = ""
    operation: str = "GET"
    iflow_name: str = ""
    artifact_id: str = ""
    description: str = ""
    sender_path: str = ""
    entity_name: str = ""
    odata_address: str = ""
    sender_adapter: str = "HTTPS"
    receiver_adapter: str = "OData"
    odata_method: str = "GET"
    groovy_needed: bool = False
    groovy_code: str = ""
    mapping_level: str = "1:1 root"
    template_id: Optional[str] = None
    error_handling: str = "default"

class DeployRequest(BaseModel):
    tenant_url: str
    username: str
    password: str
    package_id: str
    iflow_name: str
    artifact_id: str
    zip_b64: str


# =============================================================================
# CLAUDE AI STREAMING
# =============================================================================

async def stream_claude_generation(request: GenerateRequest, template: Dict, template_xml: str) -> AsyncGenerator[str, None]:
    system_prompt = """You are an expert SAP CPI developer. Modify iFlow BPMN XML templates and generate Groovy scripts.
Always produce valid importable SAP CPI artifacts. Use EXACTLY these section markers:
[INTENT_SUMMARY]...[/INTENT_SUMMARY]
[TEMPLATE_MATCH]...[/TEMPLATE_MATCH]
[IFLOW_CHANGES]...[/IFLOW_CHANGES]
[GROOVY_SCRIPT]...[/GROOVY_SCRIPT]
[VALIDATION]...[/VALIDATION]"""

    user_msg = f"""Prompt: {request.prompt}

Config — Operation: {request.operation} | iFlow: {request.iflow_name or "auto-name"} | ArtifactID: {request.artifact_id or "auto"}
Sender: {request.sender_adapter} | Receiver: {request.receiver_adapter} | Method: {request.odata_method}
Path: {request.sender_path or "/api/v1/resource"} | Entity: {request.entity_name or "not specified"}
Groovy: {"YES — " + (request.groovy_code or "generate appropriate script") if request.groovy_needed else "NO"}
Mapping: {request.mapping_level} | Error Handling: {request.error_handling}

Template: {template.get("name")} (source: {template.get("source","builtin")})
Template XML (first 2000 chars):
{template_xml[:2000]}

Instructions:
[INTENT_SUMMARY] — 2-3 sentences describing the iFlow being generated
[TEMPLATE_MATCH] — Template name used, source (builtin/uploaded), variant type
[IFLOW_CHANGES] — Bullet list of every XML change applied: name, sender path, entity, adapter, method, credential name
[GROOVY_SCRIPT] — If groovy_needed=true: complete runnable Groovy using MessageTransformBean. Else: NOT_REQUIRED
[VALIDATION] — Each check: XML structure ✓, required fields ✓, naming ✓, import-safe ✓"""

    with client.messages.stream(
        model="claude-sonnet-4-20250514",
        max_tokens=2000,
        system=system_prompt,
        messages=[{"role": "user", "content": user_msg}],
    ) as stream:
        for text in stream.text_stream:
            yield f"data: {json.dumps({'type': 'token', 'text': text})}\n\n"
            await asyncio.sleep(0)
    yield f"data: {json.dumps({'type': 'done'})}\n\n"


# =============================================================================
# API ROUTES
# =============================================================================

@app.get("/api/health")
async def health():
    uploaded = list_uploaded_templates()
    return {
        "status": "ok", "version": "2.1.0",
        "builtin_templates": len(BUILTIN_TEMPLATES),
        "uploaded_templates": len(uploaded),
        "total_template_count": len(BUILTIN_TEMPLATES) + len(uploaded),
        "claude_configured": bool(ANTHROPIC_API_KEY),
    }

@app.get("/api/templates")
async def get_templates():
    return {
        "templates": list_all_templates(),
        "builtin": list(BUILTIN_TEMPLATES.values()),
        "uploaded": list_uploaded_templates(),
    }

@app.get("/api/templates/presets")
async def get_presets():
    return {"presets": OBJECT_PRESETS}

def auto_detect_operation(zip_bytes: bytes) -> str:
    """
    Read the iFlow XML inside a ZIP and detect GET/CREATE/UPDATE/DELETE
    by inspecting the httpMethod or operation property values.
    Falls back to "GET" if nothing is found.
    """
    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
            for name in zf.namelist():
                if not name.endswith(".iflw"):
                    continue
                xml = zf.read(name).decode("utf-8", errors="replace").upper()

                # Check explicit httpMethod values
                if "<IFL:VALUE>POST</IFL:VALUE>" in xml or "HTTPMETHOD>POST<" in xml:
                    return "CREATE"
                if "<IFL:VALUE>PUT</IFL:VALUE>" in xml or "<IFL:VALUE>PATCH</IFL:VALUE>" in xml:
                    return "UPDATE"
                if "<IFL:VALUE>DELETE</IFL:VALUE>" in xml:
                    return "DELETE"
                if "<IFL:VALUE>GET</IFL:VALUE>" in xml:
                    return "GET"

                # Check OData operation property
                if "<IFL:VALUE>CREATE</IFL:VALUE>" in xml:
                    return "CREATE"
                if "<IFL:VALUE>UPDATE</IFL:VALUE>" in xml:
                    return "UPDATE"

                # Check iFlow name hints
                fname_upper = name.upper()
                if any(w in fname_upper for w in ["CREATE", "POST", "INSERT"]):
                    return "CREATE"
                if any(w in fname_upper for w in ["UPDATE", "PUT", "PATCH", "MODIFY"]):
                    return "UPDATE"
                if any(w in fname_upper for w in ["DELETE", "REMOVE"]):
                    return "DELETE"
    except Exception:
        pass
    return "GET"  # safe default


def extract_iflow_details(zip_bytes: bytes) -> Dict:
    """
    Read iFlow XML and extract useful metadata:
    sender_path, entity_name, odata_address, adapter types, groovy files.
    """
    details = {
        "sender_path": "",
        "entity_name": "",
        "odata_address": "",
        "sender_adapter": "HTTPS",
        "receiver_adapter": "OData",
        "existing_groovy": [],
    }
    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
            # Collect groovy filenames
            details["existing_groovy"] = [n for n in zf.namelist() if n.endswith(".groovy")]

            for name in zf.namelist():
                if not name.endswith(".iflw"):
                    continue
                xml = zf.read(name).decode("utf-8", errors="replace")

                # Extract address / sender path
                addr_match = re.search(r"<ifl:key>address</ifl:key>\s*<ifl:value>([^<]+)</ifl:value>", xml)
                if addr_match:
                    val = addr_match.group(1).strip()
                    if val.startswith("http"):
                        details["odata_address"] = val
                    else:
                        details["sender_path"] = val

                # Extract entitySetName
                entity_match = re.search(r"<ifl:key>entitySetName</ifl:key>\s*<ifl:value>([^<]+)</ifl:value>", xml)
                if entity_match:
                    details["entity_name"] = entity_match.group(1).strip()

                # Detect SFTP sender
                if "SFTPSender" in xml or "sftp" in xml.lower():
                    details["sender_adapter"] = "SFTP"
                elif "ProcessDirect" in xml:
                    details["sender_adapter"] = "ProcessDirect"

                # Detect SOAP receiver
                if "SOAPReceiver" in xml or "<soap" in xml.lower():
                    details["receiver_adapter"] = "SOAP"
                elif "HTTP" in xml and "receiver" in xml.lower():
                    details["receiver_adapter"] = "HTTP"
    except Exception:
        pass
    return details


@app.post("/api/templates/upload")
async def upload_template(
    file: UploadFile = File(...),
    operation: str = "auto",   # "auto" = detect from XML
):
    """Upload a single iFlow ZIP. Set operation='auto' to detect GET/CREATE/UPDATE/DELETE from XML."""
    if not file.filename.endswith(".zip"):
        raise HTTPException(400, "Only .zip files accepted")
    zip_bytes = await file.read()
    name = Path(file.filename).stem

    # Auto-detect operation if not explicitly provided
    detected_op = auto_detect_operation(zip_bytes) if operation == "auto" else operation.upper()
    details = extract_iflow_details(zip_bytes)

    meta = parse_zip_metadata(zip_bytes, detected_op, name)
    # Enrich metadata with extracted details
    meta.update({
        "sender_path":    details["sender_path"]    or meta.get("sender_path", ""),
        "entity_name":    details["entity_name"]    or meta.get("entity_name", ""),
        "odata_address":  details["odata_address"]  or meta.get("odata_address", ""),
        "sender_adapter": details["sender_adapter"],
        "receiver_adapter": details["receiver_adapter"],
        "detected_operation": detected_op,
    })

    tid = meta["id"]
    get_template_zip_path(tid).write_bytes(zip_bytes)
    get_template_meta_path(tid).write_text(json.dumps(meta, indent=2))
    return {"status": "uploaded", "template": meta}


@app.post("/api/templates/upload-batch")
async def upload_batch(files: List[UploadFile] = File(...)):
    """
    Upload ALL your iFlow ZIPs at once — mixed GET/CREATE/UPDATE/DELETE.
    Operation is auto-detected from each ZIP's XML content.
    Returns per-file results so you can see exactly what was detected.
    """
    results = []
    errors  = []

    for file in files:
        if not file.filename.endswith(".zip"):
            errors.append({"file": file.filename, "error": "Not a ZIP file — skipped"})
            continue
        try:
            zip_bytes = await file.read()
            name = Path(file.filename).stem
            detected_op = auto_detect_operation(zip_bytes)
            details     = extract_iflow_details(zip_bytes)

            meta = parse_zip_metadata(zip_bytes, detected_op, name)
            meta.update({
                "sender_path":      details["sender_path"],
                "entity_name":      details["entity_name"],
                "odata_address":    details["odata_address"],
                "sender_adapter":   details["sender_adapter"],
                "receiver_adapter": details["receiver_adapter"],
                "detected_operation": detected_op,
            })

            tid = meta["id"]
            get_template_zip_path(tid).write_bytes(zip_bytes)
            get_template_meta_path(tid).write_text(json.dumps(meta, indent=2))

            results.append({
                "file":      file.filename,
                "status":    "uploaded",
                "id":        tid,
                "name":      name,
                "operation": detected_op,
                "entity":    details["entity_name"] or "(not detected)",
                "path":      details["sender_path"]  or "(not detected)",
            })
        except Exception as e:
            errors.append({"file": file.filename, "error": str(e)})

    return {
        "uploaded": len(results),
        "errors":   len(errors),
        "results":  results,
        "errors_detail": errors,
        "summary": {
            "GET":    sum(1 for r in results if r["operation"] == "GET"),
            "CREATE": sum(1 for r in results if r["operation"] == "CREATE"),
            "UPDATE": sum(1 for r in results if r["operation"] == "UPDATE"),
            "DELETE": sum(1 for r in results if r["operation"] == "DELETE"),
        }
    }

@app.delete("/api/templates/{template_id}")
async def delete_template(template_id: str):
    if template_id in BUILTIN_TEMPLATES:
        raise HTTPException(400, "Built-in templates cannot be deleted")
    for p in [get_template_zip_path(template_id), get_template_meta_path(template_id)]:
        if p.exists(): p.unlink()
    return {"status": "deleted", "id": template_id}

@app.get("/api/templates/{template_id}/xml")
async def preview_template_xml(template_id: str):
    t = BUILTIN_TEMPLATES.get(template_id)
    if not t:
        p = get_template_meta_path(template_id)
        if not p.exists(): raise HTTPException(404, "Not found")
        t = json.loads(p.read_text())
    return {"id": template_id, "name": t["name"], "xml": get_template_xml(t)}

@app.post("/api/generate/stream")
async def generate_stream(request: GenerateRequest):
    if not ANTHROPIC_API_KEY:
        raise HTTPException(400, "ANTHROPIC_API_KEY not set")
    template = find_best_template(request.operation, request.template_id)
    if not template:
        raise HTTPException(404, "No template found")
    template_xml = get_template_xml(template)
    return StreamingResponse(
        stream_claude_generation(request, template, template_xml),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache", "X-Accel-Buffering": "no",
            "X-Template-Id": template["id"], "X-Template-Name": template["name"],
            "X-Template-Source": template.get("source", "builtin"),
        },
    )

@app.post("/api/generate/export")
async def generate_export(request: GenerateRequest):
    template = find_best_template(request.operation, request.template_id)
    if not template:
        raise HTTPException(404, "No template found")

    iflow_name  = request.iflow_name  or f"{request.operation}_{request.entity_name or 'iFlow'}"
    artifact_id = request.artifact_id or safe_slug(iflow_name)
    sender_path = request.sender_path or template.get("sender_path", "/api/v1/resource")
    entity_name = request.entity_name or template.get("entity_name", "A_Entity")
    odata_addr  = request.odata_address or template.get("odata_address", "")

    iflow_xml = get_template_xml(template)
    subs = [
        ("IFLOW_DISPLAY_NAME", iflow_name), ("ARTIFACT_ID", artifact_id),
        (template.get("name",""), iflow_name), (template.get("id",""), artifact_id),
        ("SENDER_PATH", sender_path), (template.get("sender_path",""), sender_path),
        ("ENTITY_NAME", entity_name), (template.get("entity_name",""), entity_name),
        ("ODATA_ADDRESS", odata_addr), (template.get("odata_address",""), odata_addr),
    ]
    for old, new in subs:
        if old and old != new:
            iflow_xml = iflow_xml.replace(old, new)

    groovy_code = None
    if request.groovy_needed:
        groovy_code = (request.groovy_code.strip() or DEFAULT_GROOVY).replace("IFLOW_DISPLAY_NAME", iflow_name)

    if template.get("source") == "builtin":
        zip_bytes = build_iflow_zip(iflow_name, artifact_id, iflow_xml, groovy_code)
    else:
        zip_path = get_template_zip_path(template["id"])
        zip_bytes = apply_replacements_to_zip(zip_path.read_bytes(), [(o,n) for o,n in subs if o], iflow_name)
        if groovy_code:
            out = io.BytesIO()
            with zipfile.ZipFile(io.BytesIO(zip_bytes), "r") as zin:
                with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
                    for item in zin.infolist():
                        zout.writestr(item.filename, zin.read(item.filename))
                    zout.writestr(f"src/main/resources/script/{safe_slug(iflow_name)}_transform.groovy", groovy_code)
            zip_bytes = out.getvalue()

    filename = f"{safe_slug(iflow_name)}.zip"
    return StreamingResponse(
        io.BytesIO(zip_bytes), media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )

@app.post("/api/groovy/generate")
async def generate_groovy(body: dict):
    """
    Context-aware Groovy generation.
    Accepts:
      - requirements: what the script should do (plain English)
      - iflow_context: optional dict with operation, entity_name, sender_adapter,
                       receiver_adapter, odata_method, sender_path, mapping_level
      - existing_xml:  optional iFlow XML snippet so Claude can see the actual flow
      - template_id:   optional — will load that template's XML automatically
    """
    if not ANTHROPIC_API_KEY:
        raise HTTPException(400, "ANTHROPIC_API_KEY not set")

    requirements   = body.get("requirements", "passthrough transformation")
    iflow_context  = body.get("iflow_context", {})
    existing_xml   = body.get("existing_xml", "")
    template_id    = body.get("template_id")

    # Auto-load template XML if template_id given
    if template_id and not existing_xml:
        tmpl = BUILTIN_TEMPLATES.get(template_id)
        if not tmpl:
            p = get_template_meta_path(template_id)
            if p.exists():
                tmpl = json.loads(p.read_text())
        if tmpl:
            existing_xml = get_template_xml(tmpl)
            # Merge template metadata into context if not already set
            iflow_context.setdefault("operation",         tmpl.get("http_method", "GET"))
            iflow_context.setdefault("entity_name",       tmpl.get("entity_name", ""))
            iflow_context.setdefault("sender_adapter",    tmpl.get("sender_adapter", "HTTPS"))
            iflow_context.setdefault("receiver_adapter",  tmpl.get("receiver_adapter", "OData"))
            iflow_context.setdefault("odata_address",     tmpl.get("odata_address", ""))

    # Build a rich, context-aware prompt
    ctx_block = ""
    if iflow_context:
        ctx_block = f"""
iFlow Context:
- Operation / HTTP Method : {iflow_context.get('operation', 'GET')}
- Entity / Resource Name  : {iflow_context.get('entity_name', 'not specified')}
- Sender Adapter          : {iflow_context.get('sender_adapter', 'HTTPS')}
- Receiver Adapter        : {iflow_context.get('receiver_adapter', 'OData')}
- OData Service URL       : {iflow_context.get('odata_address', 'not specified')}
- Sender Path             : {iflow_context.get('sender_path', 'not specified')}
- Message Mapping Level   : {iflow_context.get('mapping_level', 'not specified')}
- iFlow Name              : {iflow_context.get('iflow_name', 'not specified')}
"""

    xml_block = ""
    if existing_xml:
        xml_block = f"""
Relevant iFlow XML (use this to understand the message flow and adapt the script accordingly):
{existing_xml[:3000]}
"""

    prompt = f"""Write a complete, production-ready SAP CPI Groovy script for the following requirement:

REQUIREMENT:
{requirements}
{ctx_block}{xml_block}
RULES:
1. Import com.sap.gateway.ip.core.customdev.util.Message
2. Use exactly: def Message processData(Message message) as the main method signature
3. Use messageLogFactory.getMessageLog(message) for logging/attachments
4. Include try/catch with meaningful error messages
5. Add section comments (// ── Section name ──)
6. If the context shows OData/entity fields, reference those specific field names
7. If the operation is GET: focus on response parsing and enrichment
8. If CREATE/UPDATE: focus on payload validation and transformation before sending
9. If DELETE: focus on extracting the key field from request and setting it as a property
10. Return ONLY the runnable Groovy code — no markdown fences, no explanations outside comments

Write the complete script now:"""

    msg = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1500,
        messages=[{"role": "user", "content": prompt}]
    )
    groovy_code = msg.content[0].text.strip()
    # Strip markdown fences if Claude adds them despite instructions
    groovy_code = re.sub(r"^```(?:groovy)?\s*", "", groovy_code)
    groovy_code = re.sub(r"\s*```$", "", groovy_code)

    return {
        "groovy": groovy_code,
        "context_used": bool(iflow_context or existing_xml),
        "template_id": template_id,
    }

@app.post("/api/deploy")
async def deploy_to_cpi(request: DeployRequest):
    import base64
    zip_bytes = base64.b64decode(request.zip_b64)
    b64 = base64.b64encode(zip_bytes).decode()
    base_url = request.tenant_url.rstrip("/")
    auth = (request.username, request.password)
    async with httpx.AsyncClient(timeout=60) as http:
        try:
            r = await http.get(f"{base_url}/api/v1/", auth=auth, headers={"x-csrf-token": "Fetch", "Accept": "application/json"})
            csrf = r.headers.get("x-csrf-token", "")
        except Exception as e:
            raise HTTPException(502, f"Cannot reach CPI: {e}")
        if not csrf:
            raise HTTPException(502, "No CSRF token returned — check credentials/URL")
        hdrs = {"x-csrf-token": csrf, "Content-Type": "application/json", "Accept": "application/json"}
        cr = await http.post(f"{base_url}/api/v1/IntegrationDesigntimeArtifacts", auth=auth, headers=hdrs,
                             json={"Name": request.iflow_name, "Id": request.artifact_id, "PackageId": request.package_id, "ArtifactContent": b64})
        if cr.status_code not in (200, 201):
            raise HTTPException(cr.status_code, f"Create failed: {cr.text[:400]}")
        dr = await http.post(f"{base_url}/api/v1/IntegrationDesigntimeArtifacts(Id='{request.artifact_id}',Version='active')/$value", auth=auth, headers=hdrs)
        return {"status": "deployed" if dr.status_code in (200, 202) else "created", "artifact_id": request.artifact_id,
                "http_status": dr.status_code, "message": "Deployed successfully" if dr.status_code in (200, 202) else f"Created, deploy returned {dr.status_code}"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
